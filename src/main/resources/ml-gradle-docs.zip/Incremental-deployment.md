ml-gradle 3.10.0 and ml-app-deployer 3.10.0 include support for Gradle-style "incremental" deployments - only deploying resource files that are new or modified since the last time a deployment was run.

This feature is turned off by default. To try it out, just add the following to gradle.properties:

    mlIncremental=true

With this property set, ml-gradle will only deploy a resource from a resource file if that file is determined to be new or modified. ml-gradle does this by keeping track of the timestamps for which it last deployed a resource from a resource file; these timestamps by default are stored in the file "build/com.marklogic.ml-app-deployer/resource-timestamps.properties". 

## Example

Let's say you have an ./ml-config/security/users directory with 2 user files - user1.json and user2.json. Given mlIncremental is set to true, when you run "gradle -i mlDeployUsers" for the first time, the user resources will both be deployed and the time at which each file was processed will be stored in the aforementioned timestamps properties file. 

The next time you run "gradle -i mlDeployUsers", you'll see logging like this (need the "-i" flag for info-level logging):

Processing files in directory: /sample-project/src/main/ml-config/security/users
File is neither new nor modified: /sample-project/src/main/ml-config/security/users/role1.json
File is neither new nor modified: /sample-project/src/main/ml-config/security/users/role2.json

No call will be made to the Manage API, and thus the task will finish very quickly. 

## Deleting the resource timestamps file

The following tasks will automatically delete the resource timestamps file to ensure that every resource file is processed:

- mlDeploy
- mlRedeploy
- mlUndeploy

In addition, you can run the "mlDeleteResourceTimestampsFile" task at any time to delete the timestamps file. 

## Supported resource types

As of version 3.10.0, incremental deployments work for the following resource types (the reason the set of resources is limited is because the goal with 3.10.0 is to get the initial capability out and see what the value is, and it was trivial to enable for the following types):

- Groups
- Mimetypes
- Scheduled tasks
- Security resources = users, roles, amps, protected collections, privileges, external security
- Servers (but not yet a REST API server defined by rest-api-server.json)

The following resources will be supported in a later version:

- Databases and forests
- CPF resources
- Alerting resources
- View schemas
- Flexrep resources
- Temporal resources
