As a Gradle plugin, ml-gradle contributes dozens of MarkLogic-specific tasks to a Gradle project. These tasks can always be viewed by running the standard Gradle tasks command:

    gradle tasks

This will list all the tasks in your Gradle project, which includes tasks contributed by other Gradle plugins. ml-gradle organizes the tasks it contributes into task groups, each beginning with "ml-gradle". And each task provides a description of how it should be used. 

The purpose of this page then is to list every task in the latest version of ml-gradle, and, when appropriate, provide additional documentation beyond what's displayed via "gradle tasks". When a new task is added by an ml-gradle release, it will be listed here as well, similar to how the [[Property reference]] is updated with each new release.

Note too that the [[Common tasks]] page is intended to provide a summary of the most commonly used tasks, while this page provides a complete list. 

## Deploy

- mlDeploy = Deploys the application [[defined by the project|Project layout]]. 
- mlDeployToReplica = added in 4.3.0; similar to mlDeploy, but will not deploy anything that involves writing data to a database
- mlPreviewDeploy = New in 3.11.0; prints out a JSON object that defines all of the new resources to be created and resources to be modified as part of a deployment without applying any changes.
- mlPostDeploy = An "empty" Gradle task that exists solely so that project-specific tasks can be associated with it via "dependsOn". For example, you may have a "myImportData" task that uses MLCP to import data, and you need to run it after an application is deployed. Just add "mlPostDeploy.dependsOn myImportData" to your build.gradle file.
- mlPostUndeploy = Just like mlPostDeploy, but for post-processing after an application is undeployed. 
- mlRedeploy = Just like mlDeploy, but first runs mlClearModulesDatabase. This ensures that any modules e.g. removed from version control will be removed from the modules database as well. 
- mlTestConnections - new in 4.6.0
- mlUndeploy

## Admin

- mlInit
- mlInstallAdmin

## Alerting

- mlDeleteAllAlertConfigs = Useful for wiping out all alerting data from a content database. 
- mlDeployAlerting

## Cluster

- mlAddHost
- mlModifyCluster
- mlDisableSslFips
- mlEnableSslFips
- mlRemoveHost
- mlRestartCluster

## CPF

- mlDeployCpf
- mlRedeployCpf = Useful for deploying CPF from scratch. Be aware that this first clears the triggers database, which may contain triggers that are not related to CPF and would need to be deployed again.
- mlLoadDefaultPipelines

## Data

- mlLoadData - added in version 3.13.0

## Database

- mlClearContentDatabase
- mlClearDatabase
- mlClearModulesDatabase
- mlClearSchemasDatabase
- mlClearTriggersDatabase
- mlDeleteDatabase - added in 3.12.0
- mlDeployDatabases
- mlMergeContentDatabase
- mlMergeDatabase
- mlReindexContentDatabase
- mlReindexDatabase
- mlSetContentUpdatesAllowed (a task for setting this on any database doesn't exist yet)
- mlUpdateIndexes

See [[Creating forests]] for more information too.

## Database Rebalancer

These tasks are all new in version 3.17.0:

- mlDeployPartitions
- mlDeployPartitionQueries
- mlTakePartitionOffline
- mlTakePartitionOnline

## Data Movement

See [[DMSDK Tasks]] for more information.

- mlAddCollections
- mlAddPermissions
- mlDeleteCollections
- mlExportBatchesToDirectory
- mlExportBatchesToZips
- mlExportToFile
- mlExportToZip
- mlRemoveCollections
- mlRemovePermissions
- mlSetCollections
- mlSetPermissions

## Development

The "mlNew*" tasks (except for mlNewProject, which was added in version 2.7.0) were added in version 3.6.0. See [[Generating new resources]] for more information on these tasks. 

- mlCreateResource - also see https://github.com/marklogic-community/ml-gradle/wiki/Common-tasks#create-a-new-resource
- mlCreateTransform - also see https://github.com/marklogic-community/ml-gradle/wiki/Common-tasks#create-a-new-transform
- mlExportResources
- mlPrepareRestApiDependencies
- mlPrintCommands = Prints information about each command used by mlDeploy and mlUndeploy; this is just for debugging purposes (moved to this group in 3.6.0; was in "General" prior to 3.6.0)
- mlPrintProperties = New in 3.6.0; run this to see a list of all of the properties supported by ml-gradle. Can be cross-referenced with the [[Property reference]]. 
- mlPrintTokens
- mlNewProject
- mlNewAmp
- mlNewDatabase
- mlNewExternalSecurity
- mlNewGroup
- mlNewPrivilege
- mlNewProtectedCollection
- mlNewRole
- mlNewServer
- mlNewTask
- mlNewTrigger (added in 3.14.0)
- mlNewUser
- mlScaffold

In addition, you can create custom tasks using [com.marklogic.gradle.task.client.CallResourceTask](https://github.com/marklogic-community/ml-gradle/blob/master/src/main/groovy/com/marklogic/gradle/task/client/CallResourceTask.groovy) that simplify calling custom REST services. 

## Entity Services

See the [MarkLogic docs]((https://docs.marklogic.com/guide/entity-services) for more information on Entity Services.

- mlGenerateModelArtifacts

## Flexible Replication

- mlDeleteAllFlexrepConfigs
- mlDeployFlexrep
- mlDeployFlexrepAtPath
- mlDisableAllFlexrepTargets
- mlEnableAllFlexrepTargets

## Forest

- mlConfigureForestReplicas
- mlDeleteForestReplicas
- mlDeployCustomForests
- mlDeployForestReplicas
- mlPrintForestPlan

See [[Creating forests]] for more information too.

## Group

- mlDeployGroups
- mlSetTraceEvents

## Host

- mlAssignHostsToGroups = New in 3.6.0; assigns hosts to groups based on the value of mlHostGroups

## Mimetypes

- mlDeployMimetypes

## Modules

Tasks: 

- mlClearModulesDatabase = this is listed in the Database group, but relevant to Modules too
- mlDeleteModuleTimestampsFile = Deletes the file that ml-gradle uses for keeping track of when modules were last loaded
- mlExportModules = Note that this uses DMSDK, and thus requires ML 9+
- mlLoadModules = Loads new and modified modules; modules not created/modified since the last time modules were loaded will not be loaded
- mlReloadModules = Generally preferred to mlLoadModules, as it clears the modules database first, ensuring that modules e.g. removed from a project's version control system are removed from the modules database as well
- mlWatch

More information:

-- [[How modules are loaded]]
-- [[Debugging module loading]]

## Plugins

Added in 3.13.0 - see [[Installing plugins]] for more information.

- mlInstallPlugins
- mlUninstallPlugins

## qconsole

- mlExportWorkspaces  

Usage: `./gradlew mlExportWorkspaces -Puser=userName -PworkspaceNames="workspace1,workspace2"`  

Exports workspaces to `~/.qconsole/workspaces/userName`. 

- mlImportWorkspaces

Usage: `./gradlew mlImportWorkspaces -Puser=userName -PworkspaceNames="workspace1,workspace2"

Imports workspaces from `~/.qconsole/workspaces/userName`.

## REST APIs

- mlDeployRestApis - New in 3.8.1; deploys REST API instances defined by a configuration file ("rest-api.json" in the root of a configuration directory, so src/main/ml-config/rest-api.json by default) or via the properties mlRestPort and mlTestRestPort

## Schemas

Tasks: 

- mlClearSchemasDatabase = list in the Database group above, but relevant to Schemas too. This clears the entire schemas database - you may want to use mlDeleteUserSchemas instead.
- mlDeleteUserSchemas - new in 3.9.0; this deletes documents in the schemas database that are not created via the deployment of resources such as temporal collections and view schemas. Specifically, documents in the collections http://marklogic.com/xdmp/temporal/axis, http://marklogic.com/xdmp/temporal/collection, and http://marklogic.com/xdmp/view are not deleted. This behavior can be customized by modifying the "query" property of this task if necessary.
- mlLoadSchemas
- mlReloadSchemas

See [[Loading schemas]] for more information as well.

## Servers

- mlDeployServers
- mlUndeployOtherServers = "other" refers to any server that isn't the default REST server that ml-gradle creates

## Security

- mlDeployAmps
- mlDeployCertificateAuthorities
- mlDeployCertificateTemplates
- mlDeployExternalSecurity
- mlDeployPrivileges
- mlDeployProtectedCollections
- mlDeployProtectedPaths
- mlDeployQueryRolesets
- mlDeployRoles
- mlDeploySecurity
- mlDeployUsers
- mlUndeployAmps
- mlUndeployCertificateAuthorities
- mlUndeployCertificateTemplates
- mlUndeployExternalSecurity
- mlUndeployPrivileges
- mlUndeployProtectedCollections
- mlUndeployProtectedPaths
- mlUndeployQueryRolesets
- mlUndeployRoles
- mlUndeploySecurity
- mlUndeployUsers

## SQL

If you're using MarkLogic 9, consider using [TDE](https://docs.marklogic.com/guide/app-dev/TDE) instead. TDE templates are loaded into a schemas database and generally require less setup than SQL view schemas. 

- mlDeployViewSchemas

## Task (scheduled tasks)

- mlDeleteAllTasks - deletes all tasks in the ML cluster
- mlDeployTasks
- mlDisableAllTasks
- mlEnableAllTasks
- mlUndeployTasks - undeploys (deletes) only those tasks defined in your project
- mlWaitForTaskServer

## Temporal

- mlDeployTemporal

## Triggers

- mlDeployTriggers

## Unit Test

See [this sample project](https://github.com/marklogic-community/ml-gradle/tree/dev/examples/unit-test-project) for more information on using these tasks. 

- mlGenerateUnitTestSuite
- mlUnitTest
