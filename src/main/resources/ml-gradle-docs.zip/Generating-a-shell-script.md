Per [ticket 314](https://github.com/marklogic-community/ml-gradle/issues/314), a prototype was created to demonstrate generating a shell script of all the calls that ml-gradle makes during mlDeploy. The prototype involves adding a Spring RestTemplate interceptor to ml-gradle, and that interceptor then writes out every HTTP call. A text file is attached to that issue, and its contents are below for easy reference too.

To try this out, just add it to the bottom of your ml-gradle file. Then run "mlDeploy", and check out the "build/curl-(timestamp).txt" file that it generates. Then customize as needed. 

    dependencies {
        // 3.4.0 or higher should work
    	compile "com.marklogic:ml-app-deployer:3.6.0"
    }
    
    import com.marklogic.rest.util.RestConfig;
    import org.springframework.http.HttpHeaders;
    import org.springframework.http.HttpMethod;
    import org.springframework.http.HttpRequest;
    import org.springframework.http.MediaType;
    import org.springframework.http.client.ClientHttpRequestExecution;
    import org.springframework.http.client.ClientHttpRequestInterceptor;
    import org.springframework.http.client.ClientHttpResponse;
    
    import java.io.IOException;
    import java.io.Writer;
    
    public class CurlInterceptor implements ClientHttpRequestInterceptor {
    
    	private RestConfig restConfig;
    	private Writer writer;
    
    	public CurlInterceptor(RestConfig restConfig, Writer writer) {
    		this.restConfig = restConfig;
    		this.writer = writer;
    	}
    
    	@Override
    	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
    		HttpMethod method = request.getMethod();
    		if (HttpMethod.POST.equals(method) || HttpMethod.PUT.equals(method)) {
    			HttpHeaders headers = request.getHeaders();
    			String contentType = "application/xml";
    			if (MediaType.APPLICATION_JSON.equals(headers.getContentType())) {
    				contentType = "application/json";
    			}
    
    			String payload = new String(body).trim();
    			payload = payload.replace("\n","");
    			payload = payload.replace("\r","");
    
    			writer.write(String.format(
    				"curl -X %s --anyauth -u %s:%s -H \"Content-Type:%s\" -d '%s' %s\n\n",
    				method.name(),
    				restConfig.getUsername(),
    				restConfig.getPassword(),
    				contentType,
    				payload,
    				request.getURI()
    			));
    			writer.flush();
    		} else if (HttpMethod.DELETE.equals(method)) {
    			writer.write(String.format("curl -X DELETE --anyauth -u %s:%s %s\n\n",
    				restConfig.getUsername(),
    				restConfig.getPassword(),
    				request.getURI()
    			));
    			writer.flush();
    		}
    
    		return execution.execute(request, body);
    	}
    }
    
    
    ext {
    	File f = new File("build/curl-" + System.currentTimeMillis() + ".txt")
    	FileWriter writer =  new FileWriter(f)
    	CurlInterceptor interceptor = new CurlInterceptor(mlManageConfig, writer)
    	mlManageClient.getRestTemplate().getInterceptors().add(interceptor)
    
    	// Depends on ml-app-deployer 3.4.0 or higher - if using 3.3.x or earlier, change this to getAdminUsername()
    	// and getAdminRestTemplate()
    	if (mlManageConfig.getSecurityUsername() != null) {
    		mlManageClient.getSecurityUserRestTemplate().getInterceptors().add(interceptor)
    	}
    }