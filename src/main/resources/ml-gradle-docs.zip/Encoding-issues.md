If you run into encoding issues with loading modules, please see https://github.com/marklogic-community/ml-gradle/issues/155 . The solution most likely involves making the following call to modify your GRADLE_OPTS:

    export GRADLE_OPTS="-Dfile.encoding=utf-8"

Or set it to whatever encoding that you need for the content in your modules. 

Also, per [this stackoverflow post](https://stackoverflow.com/questions/21267234/show-utf-8-text-properly-in-gradle), you can add the following to gradle.properties:

    org.gradle.jvmargs='-Dfile.encoding=UTF-8'
