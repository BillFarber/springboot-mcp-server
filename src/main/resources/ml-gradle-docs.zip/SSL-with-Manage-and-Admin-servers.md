ml-gradle provides a set of configuration properties for configuring SSL connections for your Manage and Admin app servers. The [[Property reference]] page provides a list of all connection properties for these app servers.

## Configuring "simple" or insecure SSL

Starting in version 3.0.0, you can configure a simple ("simple" = insecure, where the server certificate is not validated) SSL context while connecting to the Manage and/or Admin app servers by setting the appropriate properties:

    mlManageSimpleSsl=true
    mlManageScheme=https
    mlAdminSimpleSsl=true
    mlAdminScheme=https

This approach is useful during development but is not recommended for production use cases.

With version 4.7.0 and higher, you no longer need to set `mlManageScheme=https` and `mlAdminScheme=https` if you set either "simple" SSL property to tru, or if you configure SSL via one of the approaches described below. 

## Using your JVM's default keystore

Starting in 3.17.0, you can set `mlAdminUseDefaultKeystore=true` and `mlManageUseDefaultKeystore=true` so that your JVM's default keystore is used for trusting certificates (as opposed to the "trust everything" approach employed by mlAdminSimpleSsl and mlManageSimpleSsl). Note that you'll still need to set `mlAdminScheme` and `mlManageScheme`. See the Property Reference for additional properties that you can configure when using this approach.

## Configuring 2-way SSL

Starting in ml-gradle 4.7.0, you can now configure 2-way SSL for your Manage and Admin app servers. In this scenario, you must have a key store containing a client certificate and a trust store containing the server's public certificate (these can be the same file). The following properties can then be used to configure 2-way SSL:

```
mlManageKeyStorePath=/path/to/keystore.jks
mlManageKeyStorePassword=optional password
mlManageKeyStoreType=JKS
mlManageKeyStoreAlgorithm=SunX509

mlManageTrustStorePath=/path/to/truststore.jks
mlManageTrustStorePassword=optional password
mlManageTrustStoreType=JKS
mlManageTrustStoreAlgorithm=SunX509

mlAdminKeyStorePath=/path/to/keystore.jks
mlAdminKeyStorePassword=optional password
mlAdminKeyStoreType=JKS
mlAdminKeyStoreAlgorithm=SunX509

mlAdminTrustStorePath=/path/to/truststore.jks
mlAdminTrustStorePassword=optional password
mlAdminTrustStoreType=JKS
mlAdminTrustStoreAlgorithm=SunX509
```

The "type" and "algorithm" properties default to "JKS" and "SunX509", so you do not need to include those properties if those are the correct values for your key store and trust store. 

If you need to configure SSL for loading modules, please see [[Loading modules via SSL]].

If your App-Services, REST API, Manage, and Admin app servers all require the same configuration, you can use the following properties to specify the configuration once:

```
mlKeyStorePath=/path/to/keystore.jks
mlKeyStorePassword=optional password
mlKeyStoreType=JKS
mlKeyStoreAlgorithm=SunX509

mlTrustStorePath=/path/to/truststore.jks
mlTrustStorePassword=optional password
mlTrustStoreType=JKS
mlTrustStoreAlgorithm=SunX509
```
