Version 3.11.0 adds a task named "mlPreviewDeploy" which is used for printing out a JSON report of all new resources to be created and resources to be modified, but without making any changes:

    gradle mlPreviewDeploy

For resources being modified, a diff is performed using the [zjsonpatch](https://github.com/flipkart-incubator/zjsonpatch) library, which outputs a [JSON patch](https://tools.ietf.org/html/rfc6902) object to capture the changes. The "JSON report" is then an array of objects, each defining a new resource to be created or a resource to be modified. 

An example of the report:

```
{
  "message" : "Will create new resource at: http://localhost:8002/manage/v2/users",
  "resource" : {
    "user-name" : "new-user"
  }
}, {
  "message" : "Will update resource at: http://localhost:8002/manage/v2/users/sample-project-manager/properties",
  "existingResource" : {
    "user-name" : "sample-project-manager",
    "role" : [ "sample-project-manager-role" ]
  },
  "patch" : [ {
    "op" : "add",
    "path" : "/role/1",
    "value" : "rest-admin"
  } ]
}
```

The preview only covers resources managed via the Manage API - thus, the task attempts to disable the loading of modules and schemas by clearing out the list of module paths and nulling out the schemas path. In addition, the preview only supports capturing changes for JSON resource files - for XML resource files, a message will be included in the report stating that XML is not yet supported for capturing changes. Furthermore, calls to the Configuration Management API - CMA, as `/manage/v3` - cannot be previewed. 

The task is similar to mlDeploy in that it accepts an "ignore" property for optionally specifying a list of command class names to ignore. This can be used to omit certain resources from a preview, or to omit custom commands for loading modules and/or schemas. 