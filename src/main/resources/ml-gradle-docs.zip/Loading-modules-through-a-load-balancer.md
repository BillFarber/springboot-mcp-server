**This only pertains to ml-gradle versions 2.x**. Starting with 3.0.0, ml-gradle loads non-REST modules via the Java Client and port 8000. 

ml-gradle by default loads modules via XCC and port 8000 - it's a bit faster than using the REST API (and as of 2.4.0 ml-gradle, the XccAssetLoader has a few more features than RestApiAssetLoader does).

This is sometimes a problem when loading modules through a load balancer. The load balancer will accept HTTP traffic, but an XCC request will be rejected by MarkLogic with a 400 error message asking if the server is an XDBC server. 

XCC has a fix for this - the "xcc.httpcompliant" environment property must be set to "true" - see https://help.marklogic.com/knowledgebase/article/View/32/15/load-balancing-in-marklogic . You can ensure that's always the case in Gradle by doing the following:

    task setXccHttpCompliant {
      System.setProperty("xcc.httpcompliant", "true")
    }

    mlDeploy.dependsOn setXccHttpCompliant
    mlLoadModules.dependsOn setXccHttpCompliant // in case someone invokes this directly

