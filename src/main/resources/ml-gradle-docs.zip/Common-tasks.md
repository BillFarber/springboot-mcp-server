You can run "gradle tasks" to see all the tasks that ml-gradle offers. Below are some of the more commonly used tasks with a description of how each one works. See the [[Task reference]] for a complete list. 

## Deploying an application

    gradle mlDeploy

Perform a full deploy of an application - see the [README page and example applications](https://github.com/marklogic-community/ml-gradle) for more info. Normally, after running this once, you won't run this too often, as there are dozens of more fine-grained tasks to deploy just the updated parts of an application (i.e. if you update a role, just run mlDeployRoles, which will be much faster than waiting for a full deploy to be performed).

## Undeploying an application

    gradle mlUndeploy

Undeploys an application, removing all resources that are were deployed via mlDeploy.

## Loading modules

    gradle mlLoadModules

Loads modules from one or more directory paths via the Client Rest API. See [[How modules are loaded]] for more information. 

## Automatically load new/modified modules

    gradle mlWatch

Runs an infinite loop, checking every second for modifications in the application's set of module paths. This is a useful task to run when you're developing modules and you only want to load what you've created/modified, and you don't want to have to run a command after every change to load your modules. It's very common to having this running all the time during development, only stopping it so that some other task can be run, and then firing it back up again. 

## Reload modules

    gradle mlReloadModules

Combines mlClearModules and mlLoadModules together. This is useful to run when you want to ensure you have a clean modules database - i.e. some modules may have been deleted from your version control system, but they're still hanging out in your modules database. 

## Clearing the content database

    gradle mlClearContentDatabase -Pconfirm=true

Deletes all documents in your content database. You must include the property -Pconfirm=true, which is required to decrease the chance that you run this task accidentally. 

## Create a new resource

You can create - i.e. stub out - a new REST API resource (or "service") via the following command:

    gradle mlCreateResource -PresourceName=sample

As of 2.6.0, you can specify "-PresourceType=sjs" to create a serverside JavaScript resource.

The resourceName project property is required; it is used to name the resource file and its namespace. The following files will be created in your project:

1. src/main/ml-modules/services/sample.xqy
1. src/main/ml-modules/services/metadata/sample.xml

The metadata file is used to provide metadata to the REST API when your resource is installed. You can customize this as you wish. 

## Create a new transform

You can create - i.e. stub out - a new REST API transform via the following command:

    gradle mlCreateTransform -PtransformName=sample -PtransformType=xsl

where transformType defaults to "xqy" and can be either "xqy" or "xsl" or, as of 2.6.0, "sjs". 

This will create the following file in your project:

1. src/main/ml-modules/transforms/sample.xqy
