The MarkLogic [Data Hub Framework](https://marklogic.github.io/marklogic-data-hub/) (DHF) features a Gradle plugin that embeds a certain version of ml-gradle. If you'd like to force Gradle to use a specific version of ml-gradle while using DHF, you can use the below example in build.gradle as a starting point (change the version numbers of DHF and ml-gradle as needed):

```
buildscript {
    repositories {
        maven {
            url "https://plugins.gradle.org/m2/"
        }
    }
    dependencies {
        classpath "gradle.plugin.com.marklogic:ml-gradle:3.14.0"
        classpath "gradle.plugin.com.marklogic:ml-data-hub:4.2.2"
    }
}

plugins {
    id 'net.saliman.properties' version '1.4.6'
}

apply plugin: "com.marklogic.ml-data-hub"
```

## Speeding up DHF deployments

Starting with version 3.11.0 of ml-gradle, you should get faster deployments by setting the following properties in gradle.properties (assuming you're on MarkLogic 9.0-5 or greater):

```
mlDeployForestsWithCma=true
mlDeployAmpsWithCma=true
mlDeployPrivilegesWithCma=true
```

The first one - for forests - should help because DHF creates several databases. The other two - for amps and privileges - will only really help if you several or more of each of these.