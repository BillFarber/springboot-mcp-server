Similar to non-REST modules, schemas are loaded by default via the App-Services server on port 8000. The [Property reference](https://github.com/marklogic-community/ml-gradle/wiki/Property-reference#app-services-server-connection-properties) defines the various properties for how a connection is made to 8000, and [[Configuring security]] describes the roles that a user must have.  

Note that when a new database is created, such as via `mlNewProject`, it would point to the out-of-the-box Schemas database as its schemas database. Most of the time, you will want a database specific to your application for managing schemas. Thus, it is recommended to add a file to your `src/main/ml-config/databases` directory that defines a schemas database to create. You can see this setup in this [example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/schemas-project/src/main), which also shows how the content database is associated with the schemas database. 

## Specifying collections and permissions for schemas

As of version 2.6.0, schemas can be loaded from child directories of `src/main/ml-schemas`, and they can also be loaded into custom collections. See https://github.com/marklogic-community/ml-javaclient-util/wiki/Loading-files#specifying-collections-and-permissions for more information. 

As of 4.6.0, the properties `mlCascadeCollections` and `mlCascadePermissions` can be set to `true` so that the settings in `collections.properties` and `permissions.properties` will be applied to child directories, unless a child directory has its own files. 

## Loading TDE templates

As of version 2.7.0, TDE templates no longer need to have a "tdex" or "tdej" suffix. Instead, any document with a URI starting with "/tde" will be put into the "http://marklogic.com/xdmp/tde" collection. Thus, for a schemas directory of `src/main/ml-schemas` (which is the default location for schemas in an ml-gradle project), you would store your TDE templates in `src/main/ml-schemas/tde`. 

As of version 4.3.5, when loading schemas into MarkLogic version 10.0-9 or higher, TDE templates will be loaded via the new [tde.templateBatchInsert](https://docs.marklogic.com/tde.templateBatchInsert) function. This function handles validating all of your TDE templates at once, thus avoiding errors that can occur when templates are validated individually. Note that as stated in the documentation for `tde.templateBatchInsert`, **your user must have the tde-admin** role. 

If you receive an error when loading schemas and you're using a version of ml-gradle less than 4.5.0, you may see the following error message:

    Server Message: Server (not a REST instance?) did not respond with an expected REST Error message

If you encounter this, then either upgrade to ml-gradle 4.5.0 or at least ml-gradle 4.3.6. In the latter, the script that is used to load the TDE template via `tde.templateBatchInsert` will be logged. You can then paste this script into qconsole to see the actual error.

## Generating Query-Based Views

As of version 4.6.0, you can now generate a Query-Based View (QBV) from either a JavaScript or XQuery module. The module will be evaluated by MarkLogic, producing an XML view that is inserted into your application's schemas database. 

The module should use the [generateView](https://docs.marklogic.com/ModifyPlan.prototype.generateView) function to generate view (or [generate-view](https://docs.marklogic.com/op:generate-view) if the module is written using XQuery). It must also be located in the `/qbv` directory within a schemas path. 

For example, based on the default path of `src/main/ml-schemas`, a file named e.g. `myView.sjs` would be added at `src/main/ml-schemas/qbv/myView.sjs`. A very simple script would simply produce a new view based on an existing one:

```
'use strict';
const op = require('/MarkLogic/optic');
op.fromView('Medical', 'Authors').generateView('alternate', 'authors');
```

For XQuery, a file named e.g. `my-view.xqy` would be added to the same directory and look like this:

```
xquery version "1.0-ml";
import module namespace op="http://marklogic.com/optic" at "/MarkLogic/optic.xqy";
op:from-view("Medical", "Authors")
   => op:generate-view("alternate", "authors")
```
    

## Loading schemas into different databases

As of version 3.11.0, schemas can be loaded from database-specific paths, as defined in the [[Project layout]] page. Example:

```
databases
│       content-database.json
│       my-schemas-database.json
|       my-other-schemas-database.json
└───my-schemas-database
    └───schemas
            my-schema.xsd
└───my-other-schemas-database
    └───schemas
            my-other-schema.xsd
```

## Validating TDE templates

Starting in release 3.13.0, TDE templates are validated by default. The property "mlTdeValidationEnabled" can be set to "false" to disable this behavior. 

## Token replacement

As of release 3.16.1, tokens will be replaced in schema files, just like they are for modules. 