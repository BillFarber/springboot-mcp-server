ml-gradle provides a set of properties for each connection that it makes to MarkLogic that allow for an SSL connection
to be configured (note that "SSL" is used in this documentation to imply the use of either SSL or TLS for secure
connections). The properties support the following scenarios:

1. "One way" SSL, where the client only needs to trust the certificate presented by the MarkLogic app server.
2. "Two way" SSL, where the client must also present a certificate to the server.
3. "Simple" SSL, where the client does not need to trust the server certificate. This approach is only recommended for development and not for production use cases. 

The [MarkLogic documentation](https://docs.marklogic.com/11.0/guide/security-guide/en/configuring-ssl-on-app-servers.html) 
describes how to configure a MarkLogic app server to require SSL.

For configuring SSL for the App-Services app server and for a REST API app server, please see [[Loading modules via SSL]]. For configuring SSL for the Manage and Admin app servers, please see [[SSL with Manage and Admin servers]]. 

This guide will be updated soon to replace both of the above pages so that all SSL configuration needs are addressed in one place. 