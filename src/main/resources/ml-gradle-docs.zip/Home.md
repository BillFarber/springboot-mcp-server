To learn more about ml-gradle, choose from one of the links below, or browse the index of Wiki pages on the right:

- **Getting an error with ml-gradle?** Please see the [[Debugging guide]]. 
- [[Getting started]] - this walks you through the basics of setting up a new project
- [[Project layout]] - see examples of what a typical ml-gradle project looks like
- [Example projects](https://github.com/marklogic-community/ml-gradle/tree/master/examples) - working examples of some of the features of ml-gradle
- [[Port reference]] - list of the MarkLogic server ports commonly used by ml-gradle
- [[Property reference]] - list of all properties supported by ml-gradle
- [[Resource reference]] - list of all resources supported by ml-gradle
- [[Task reference]] - list of all tasks supported by ml-gradle

Looking to migrate a Roxy project to ml-gradle? Please see [the migration guide](https://github.com/marklogic-community/ml-gradle/wiki/Migrating-a-Roxy-project-to-ml-gradle). 

Need to use ml-gradle, but you're in an environment where you can't use Gradle to download ml-gradle and its dependencies? See [[Offline support]]. 

## ml-gradle Configuration

"Configuration" can refer to several aspects of ml-gradle; the following links describe the different ways that ml-gradle can be configured:

- [[Configuring ml-gradle]] describes how the ml-gradle plugin can be configured via Gradle properties and scripting in the Gradle build file. 
- [[Configuring resources]] describes how to create files that define the different MarkLogic resources for an application, such as databases, app servers, scheduled tasks, etc. 
- [[Configuring security]] describes the different MarkLogic users that can be used for each of the jobs performed by ml-gradle during a deployment

## Loading modules

ml-gradle provides a number of features for loading modules, and there are a number of things to be aware of as well, as described by these pages:

- [[How modules are loaded]] goes over the basics of how ml-gradle loads modules
- [[Bundles]] describes how you can depend on external bundles that include MarkLogic modules
- [[Debugging module loading]]
- [[Loading modules through a load balancer]]
- [[Loading modules via SSL]]
- [[Loading modules with static checking]]
- [[Watching for module changes]]

## Integration guide

ml-gradle easily integrates with other Java-based MarkLogic tools, as described by the following pages:

- [[MarkLogic Content Pump (mlcp) and Gradle]]
- [[Corb and Gradle]]
- [[Data Movement API|DMSDK Tasks]]

## Extending ml-gradle

A common way to extend ml-gradle is by creating your own Gradle tasks, but it can be extended and overridden at lower levels as well:

- [[Dynamically creating tasks]] describes techniques for reducing duplication across many custom Gradle tasks
- [[Writing your own task]] describes the support ml-gradle provides for custom tasks for your project
- [[Writing your own command]] describes how to extend and customize the behavior of mlDeploy and mlUndeploy
- [[Writing a task that talks to a different port]] describes how to write tasks that talk to a variety of ports in MarkLogic