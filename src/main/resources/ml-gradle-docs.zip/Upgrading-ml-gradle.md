In general, upgrading ml-gradle is trivial and is upgraded like any other Gradle plugin - just change the version number in your build.gradle file, e.g.:

    plugins {
      id "com.marklogic.ml-gradle" version "change this!"
    }

The only other thing to take into consideration is if any change listed in the [release notes](https://github.com/marklogic-community/ml-gradle/releases) will cause issues for your project. 

See [the Gradle docs](https://docs.gradle.org/3.4.1/userguide/plugins.html) for more info on Gradle plugins. 