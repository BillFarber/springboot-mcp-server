"Configuring security" in the context of this page refers to configuring which MarkLogic user is used for each job that ml-gradle performs during a deployment.

ml-gradle supports different MarkLogic user accounts for the various jobs performed during a deployment. See [the sample project gradle.properties](https://github.com/marklogic-community/ml-gradle/blob/master/examples/sample-project/gradle.properties) file for an example of configuring those accounts. The [[Property Reference]] also provides information about these accounts, which are summarized below:

| User Property | Password Property | Description |
| --- | --- | --- |
| mlUsername | mlPassword | Default user that is used when any of the below are not specified |
| mlManageUsername | mlManagePassword | For calls to the Manage server on port 8002 on port 8001; the user must have the `manage-admin` role. Other than for loading modules, nearly all calls made by ml-gradle are to the Manage server. |
| mlSecurityUsername | mlSecurityPassword | For calls to security endpoints in the Manage server on port 8002 that require a user with both the `manage-admin` and `security` roles (often the "admin" user). Prior to version 3.4.0, these were named `mlAdminUsername` and `mlAdminPassword`. |
| mlAppServicesUsername | mlAppServicesPassword | For loading non-REST extension modules, schemas, and data, all of which is performed via the App-Services app server on port 8000 (identified by `mlAppServicesPort`) by default. Per the [REST API docs for loading documents](https://docs.marklogic.com/REST/POST/v1/documents), this user must have either the `rest-writer` role or both the `rest-reader` and `rest-writer` privileges. In addition, the `xdmp-eval-in` privilege is required. This can be granted to the user via the `rest-evaluator`, the `security` role, or a custom role. Finally, if you are loading TDE templates on MarkLogic 10.0-9 or higher, your user must have the `tde-admin` role. See [[Loading schemas]] for more information on TDE templates. |
| mlRestAdminUsername | mlRestAdminPassword | For loading REST extensions, such as resources and transforms, which must be performed by the app server identified by `mlRestPort`. This user must have the `rest-admin` role but does not require the `xdmp-eval-in` privilege. |

The use of two different properties for loading modules is due to the REST API's difference in how it treats REST extensions and non-REST modules. See [[How modules are loaded]] for more information.

Also see [[Connecting to the Manage API]] for more information on how to control the connection to the Manage API. 

Regarding mlSecurityUsername (3.4.0 and later) and mlAdminUsername (prior to 3.4.0) - the specific use case for this is when you want to create an application-specific user with at least the manage-admin role, but you need some existing user in order to perform that operation. Often, that is the MarkLogic admin user. But you may also have an existing user that has both the manage-admin and security roles, and you wish to use this instead, thus limiting the use of the admin user as much as possible (always a good goal). 

The change from "mlAdminUsername" to "mlSecurityUsername" in 3.4.0 was made to make this distinction more clear - an admin user isn't required, simply a user with the "security" role, in addition to "manage-admin".
