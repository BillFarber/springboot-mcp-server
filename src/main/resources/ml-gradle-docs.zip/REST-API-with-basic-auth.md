If you want your REST API server to use basic authentication, as of ml-gradle 2.6.0, you'll need to do 2 things.

First, because the [/v1/rest-apis](http://docs.marklogic.com/REST/POST/v1/rest-apis) endpoint doesn't allow for an authentication strategy to be set, you'll have to modify the REST API server via ml-config/servers/rest-api-server.json, e.g.:

    {
      "server-name": "%%NAME%%",
      "authentication": "basic"
    }

Then, you'll need to modify the ml-gradle configuration so that the DatabaseClient that's constructed uses basic auth instead of digest:

    ext {
      mlAppConfig {
        restAuthentication = com.marklogic.client.DatabaseClientFactory.Authentication.BASIC
      }
    }

Or if you're using version 2.7.0 or higher, just set a property:

    mlRestAuthentication=BASIC
