See the [flexrep-example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/flexrep-project) for an example of how to configure [Flexrep](https://docs.marklogic.com/guide/flexrep). 

You can try this project out locally by doing the following:

1. Clone this repository
1. cd examples/flexrep-project
1. gradle mlDeploy

See the comments in the build.gradle file for more info, along with the README files in the ml-config directories in the project. 