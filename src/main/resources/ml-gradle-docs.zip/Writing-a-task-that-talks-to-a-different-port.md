**This page is largely obsolete** and the information in [[Writing-your-own-task]] should be of more assistance in creating custom Gradle tasks. 

## Interacting with the Management REST API 

Writing a task that talks to the Management REST API on port 8002 is straightforward - you can write a custom task that references mlManageClient, which is an instance of [ManageClient](https://github.com/marklogic-community/ml-app-deployer/blob/master/src/main/java/com/marklogic/mgmt/ManageClient.java):

    task example {
      doLast {
        mlManageClient.putJson("...")
      }
    }

Or you can extend MarkLogicTask and access the ManageClient that way as well:

    task example(type: com.marklogic.gradle.task.MarkLogicTask) {
      doLast {
        getManageClient().putJson("...")
      }
    }

## Interacting with a Client REST API

If you need to talk to the REST API port associated with your application, you can extend MarkLogicTask and get an instance of a MarkLogic DatabaseClient:

    task example(type: com.marklogic.gradle.task.MarkLogicTask) {
      doLast {
        def client = newClient()
        // Do something with the client - see http://docs.marklogic.com/javadoc/client/index.html
      }
    }

As of version 3.0.0, the underlying "mlAppConfig" (an instanceof AppConfig in ml-app-deployer) object that ml-gradle creates also has some methods for creating a DatabaseClient for specific databases, e.g.

    def modulesClient = mlAppConfig.newModulesDatabaseClient()
    def schemasClient = mlAppConfig.newSchemasDatabaseClient()
    def anyDbClient = mlAppConfig.newAppServicesDatabaseClient("any-database-name")

If you need to talk to a different port, or you'd prefer a different API for sending HTTP requests, then give [HTTPBuilder](https://github.com/jgritman/httpbuilder) a try. You'll need to include it in your buildscript dependencies:

    buildscript {
      dependencies {
        classpath 'org.codehaus.groovy.modules.http-builder:http-builder:0.7'
      }
    }

And then you can import the classes you need and write your task. See the [HTTPBuilder Wiki](https://github.com/jgritman/httpbuilder/wiki) for examples of how to use it. 

Also see the [RESTClient API](https://github.com/jgritman/httpbuilder/wiki/RESTClient) in HTTPBuilder - you may find this to be a better fit than HTTPBuilder.

There is also [an issue](https://github.com/marklogic-community/ml-gradle/issues/92) for providing nicer integration with HTTPBuilder.

    