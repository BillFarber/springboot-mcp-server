The sections below (ordered in the same fashion as the [Manage API docs](http://docs.marklogic.com/REST/management) provide information about each resource type that ml-gradle supports. 

Each section defines where resource payload files should be replaced, relative to a configuration directory. ml-gradle defaults to a single configuration directory of "src/main/ml-config".

Each resource is deployed via the Manage server on port 8002, unless otherwise noted. And the connection to port 8002 is made using the user specified by mlManageUsername, or mlUsername if mlManageUsername is not set, unless otherwise noted. 

For the tasks specific to each resource, please see the [[Task reference]] and the section with the same name as the resource type you're interested in. 

## Alerting

- [API Docs](http://docs.marklogic.com/REST/management/alerting)
- Paths = ./alert, and ./databases/(name of database)/alert
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/alert-project), and an example of [database-specific alerting](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/alert-config/databases)

## App servers

- [API Docs](http://docs.marklogic.com/REST/management/app-servers)
- Path = ./servers
- [Example files](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/servers)
- See the note in the "REST API" section below about using `./servers/rest-api-server.json` to configure the REST API servers associated with `mlRestPort` and `mlTestRestPort`.

## Clusters

- [API Docs](http://docs.marklogic.com/REST/management/clusters)
- Path = ./clusters
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/cluster-test/clusters)

## Configurations

Configuration Management API (CMA) configurations are supported as of version 3.7.0. Note though that while configurations can be deployed, the CMA endpoint in MarkLogic does not yet support deleting configurations. 

- [API Docs](http://docs.marklogic.com/REST/POST/manage/v3)
- Path = ./configurations
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/cma/configurations)
- See [the ml-app-deployer docs on CMA](https://github.com/marklogic-community/ml-app-deployer/wiki/Configuration-Management-API) for more information too. 

## CPF

- [API Docs](http://docs.marklogic.com/REST/management/content-processing-framework-(cpf))
- Path = ./cpf
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/cpf-project)

## Databases

- [API Docs](http://docs.marklogic.com/REST/management/databases)
- Path = ./databases
- [Example files](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/databases)
- [Properties](https://github.com/marklogic-community/ml-gradle/wiki/Property-reference#database-and-forest-properties)

Note that some resources can be defined in directories under "./databases/(name of database)" - see this [ml-app-deployer Wiki page](https://github.com/marklogic-community/ml-app-deployer/wiki/Deploying-resources-to-databases) for more information. 

Sub-databases are also supported, but docs have not been written on that yet. In the meantime, see the layout of this [example project](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/subdatabases/databases). 

## Database Rebalancer 

These resources are part of configuring Tiered Storage for a database.

- [API Docs](http://docs.marklogic.com/REST/management/database-rebalancer)
- Also see the [Tiered Storage docs] for more information on requirements for your database
- Path for range partitions = ./databases/(name of database)/partitions
- Path for query partitions = ./databases/(name of database)/query-partitions
- [Partitions example project](https://github.com/marklogic-community/ml-gradle/tree/dev/examples/partition-project)
- More information at [ml-app-deployer](https://github.com/marklogic-community/ml-app-deployer/wiki/Database-Rebalancer)
- Also see the [Task Reference](https://github.com/marklogic-community/ml-gradle/wiki/Task-reference#database-rebalancer) for tasks for taking partitions online and offline

## Flexible Replication

- [API Docs](http://docs.marklogic.com/REST/management/flexible-replication)
- Path = ./flexrep, and ./database/(name of database)/flexrep
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/flexrep-project)
- Example of deploying [pull configs](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/flexrep-config/databases/other-sample-app-content/flexrep)
- New in 3.9.0 - flexrep/pulls is now supported for deploying pull configurations

## Forests

ml-gradle creates forests when it deploys a database. See [[Creating forests]] for the different ways that forests can be created, which also includes how replicas are created. 

- [API Docs](http://docs.marklogic.com/REST/management/forests)
- Path (for custom forests) = ./forests/(name of database)
- [Example project for custom forests](https://github.com/marklogic-community/ml-gradle/tree/master/examples/custom-forests-and-replicas-project)

## Groups

- [API Docs](http://docs.marklogic.com/REST/management/groups)
- Path = ./groups
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/groups)

## Mimetypes

- [API Docs](http://docs.marklogic.com/REST/management/mimetypes)
- Path = ./mimetypes
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/src/main/ml-config/mimetypes)
- [More information in ml-app-deployer](https://github.com/marklogic-community/ml-app-deployer/wiki/Mimetypes)

## Modules

Modules are not a Manage API resource, but rather documents loaded via a MarkLogic REST server. See [[How modules are loaded]] for more information.

## REST APIs

MarkLogic provides an endpoint for creating a REST server, a content database, and a modules database in a single call. The endpoints for these are listed under the "Client API" in the REST API docs, but they are invoked on port 8002 as part of the Manage API. Thus, they're treated as another resource type that ml-gradle can deploy and undeploy.

- [API Docs](http://docs.marklogic.com/REST/client/service-management)
- Path = ./rest-api.json . ml-gradle will look for this specific file when it calls the REST endpoint for creating a REST API server. 
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config)
- For further customization of the REST API server (the REST management endpoint only allows for a handful of properties to be customized), it is recommended to create a file at `./servers/rest-api-server.json`. ml-gradle will use this file for the REST API servers associated with `mlRestPort` and also `mlTestRestPort` if it is defined. 

## Scheduled Tasks

- [API Docs](http://docs.marklogic.com/REST/management/scheduled-tasks)
- Path = ./tasks
- [Example files](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/tasks)
- [More information](https://github.com/marklogic-community/ml-app-deployer/wiki/Scheduled-Tasks)

## Schemas

Schemas are not a Manage API resource, but rather documents loaded via a MarkLogic REST server. See [[Loading schemas]] for more information. 
 
## Security - Amps

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/amps
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/security/amps)

## Security - Certificate Authorities

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/certificate-authorities
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/src/main/ml-config/security/certificate-authorities)
- As of 3.12.0, certificate authority filenames must end with ".crt". This will be made configurable shortly in the future. 
- [More information](https://github.com/marklogic-community/ml-app-deployer/wiki/Certificate-Authorities)

## Security - Certificate Templates

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/certificate-templates
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/ssl-project/src/main/ml-config/security/certificate-templates)

## Security - Certificate Templates / Host Certificates (new in 3.8.0)

- [API Docs](http://docs.marklogic.com/REST/POST/manage/v2/certificate-templates/[id-or-name])
- Path = ./security/certificate-templates/host-certificates/(name of certificate template)

Each directory under host-certificates must match the name of an already-deployed certificate template. The directory must then have two files in it - a public certificate file ending in ".crt", and a private key file ending in ".key". For an example, [see this example in ml-app-deployer](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/host-certificates/security/certificate-templates). 

New in 5.1.0 - the MarkLogic 12.0 server release supports providing a passphrase for an encrypted private key. ml-gradle supports configuring a passphrase for an encrypted private key via the `mlHostCertificatePassphrases` property. This property accepts a comma-delimited sequence of private key file base name followed by a passphrase. For example, if you have two separate private key files named `host1.key` and `host2.key` with passphrases of `pass1` and `pass2`, you could configure the property like so:

    mlHostCertificatePassphrases=host1,pass1,host2,pass2

In case a passphrase has a comma in it, you can configure the `mlHostCertificatePassphrasesDelimiter` property (also introduced in the ml-gradle 5.1.0 release) to be a different value that is not present in any passphrases. 

## Security - Credentials

- [API Docs](https://docs.marklogic.com/REST/PUT/manage/v2/credentials/properties)
- Path = ./security/credentials
- [Example JSON file](https://github.com/marklogic/ml-app-deployer/pull/506/files#diff-54a227f2fe3f8f4b049cdf8e02c3f6dcf48e766f7fcf6676631fc72c96ab7a4a)
- [Example XML file](https://github.com/marklogic/ml-app-deployer/pull/506/files#diff-510f1637aa8cfba0669770d025731dc2d5263a335966ee88fb98ee18a8403e43)
- Added in 4.8.0.

## Security - External Security

This resource type is supported on ML8 but not yet ML9. 

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/external-security
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/security/external-security)

## Security - Privileges

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/privileges
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/security/privileges)
- Also see [the ml-app-deployer Wiki page on privileges](https://github.com/marklogic-community/ml-app-deployer/wiki/Privileges)

## Security - Protected Collections

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/protected-collections
- [Example file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/security/protected-collections)

## Security - Protected Paths

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/protected-paths
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/src/main/ml-config/security/protected-paths)

## Security - Query Rolesets

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/query-rolesets
- [Example file](https://github.com/marklogic-community/ml-app-deployer/tree/master/src/test/resources/sample-app/src/main/ml-config/security/query-rolesets)

## Security - Roles

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/roles
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/role-project)
- See [the ml-app-deployer docs on roles](https://github.com/marklogic-community/ml-app-deployer/wiki/Roles)

## Security - Secure Credentials

- [API Docs](https://docs.marklogic.com/REST/POST/manage/v2/credentials/secure)
- Path = ./security/secure-credentials
- [Example file](https://github.com/marklogic/ml-app-deployer/pull/460/files#diff-0bb7995bc32ae5220ff30fd7d6be9917404378bf3887edf2908eb59e7a9d49ee)
- Added in 4.4.0.

## Security - Users

- [API Docs](http://docs.marklogic.com/REST/management/security)
- Path = ./security/users
- [Example files](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/security/users)

## SQL Schemas and Views

Note that [TDE](https://docs.marklogic.com/guide/app-dev/TDE) in ML9 is an alternative to SQL view schemas.

- [API Docs](http://docs.marklogic.com/REST/management/sql-schemas-and-views)
- Path = ./view-schemas, and ./databases/(name of database)/view-schemas
- [Example files](https://github.com/marklogic-community/ml-gradle/tree/master/examples/sample-project/src/main/ml-config/view-schemas)

## Task Server

- [API Docs](http://docs.marklogic.com/REST/PUT/manage/v2/task-servers/[id-or-name]/properties)
- Path = ./task-servers
- [Example file](https://github.com/marklogic-community/ml-app-deployer/blob/master/src/test/resources/sample-app/src/main/ml-config/task-servers/task-server.json)
- The command for updating the task server assumes that the task server is named "TaskServer", as there is not yet a way to change that. 

## Temporal

- [API Docs](http://docs.marklogic.com/REST/management/temporal)
- Path = ./temporal, and ./databases/(name of database)/temporal
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/temporal-project)
- [Example project with LSQT](https://github.com/marklogic-community/ml-gradle/tree/master/examples/temporal-lsqt-project)

## Triggers

- [API Docs](http://docs.marklogic.com/REST/management/alerting)
- Path = ./triggers, and (as of 3.6.2) ./databases/(name of triggers database)/triggers
- [Example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/triggers-project)
