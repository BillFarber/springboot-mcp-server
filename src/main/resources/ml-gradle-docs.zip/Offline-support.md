## Packaging up your entire application for offline deployment

You can use ml-gradle to package up your application such that it can be deployed using ml-gradle in an offline or "disconnected" environment.

For an example of this, please see the [build.gradle file in the disconnected example project](https://github.com/marklogic-community/ml-gradle/tree/master/examples/disconnected-project). 

## Packaging up ml-gradle for offline usage

If you'd like to use ml-gradle in an environment where you can't connect to repositories like jcenter and mavenCentral, you can copy some of what's in the disconnected-project build.gradle file to package up a zip of ml-gradle and its dependencies and then reference those from the filesystem in your build.gradle file. Alternatively, you can build an "uber" jar - see the next section below. 

To do this, you'll need to be in a "connected" environment to begin so you can download ml-gradle dependencies. You'll also need access to Gradle and a build.gradle file to edit.

First, let's declare ml-gradle as a regular application dependency instead of a buildscript dependency (the version number of ml-gradle doesn't matter, this will work with any version):

    repositories {
      mavenCentral()
    }
    configurations {
      mlgradle
    }
    dependencies {
      mlgradle "com.marklogic:ml-gradle:4.5.0"
    }

Next, let's make a task that copies ml-gradle and all of its dependencies to a directory (any directory is fine here):

    task copyMlGradleDependencies(type: Copy) {
      from configurations.mlgradle
      into "build/ml-gradle-dependencies"
    }

You now have everything you need to use ml-gradle in an offline environment. You'll probably want to package these jars up into a zip/tar and copy it to your offline environment - you can of course use Gradle for that too (see the [docs on Zip](https://docs.gradle.org/current/dsl/org.gradle.api.tasks.bundling.Zip.html) for more info - note that this will create the file under build/distributions by default):

    task buildMlGradleZip (type: Zip, dependsOn: ["copyMlGradleDependencies"]) {
      from "build/ml-gradle-dependencies"
      archiveName "ml-gradle-package.zip"
    }

Once you have your ml-gradle dependencies in your offline environment, you'll then apply the Gradle plugin in a slightly different manner (this is shown in the disconnected-project above) - assuming we've copied our jars to a directory named "ml-gradle-dependencies":

    buildscript {
      dependencies {
        classpath fileTree(dir: "ml-gradle-dependencies", include: "*.jar")
      }
    }
    apply plugin: "com.marklogic.ml-gradle"

You should be in business now - no repositories needed, you have everything you need for ml-gradle in that directory of jars.

If you're using MarkLogic's Data Hub Framework, then [this gist](https://gist.github.com/awanczowski/eea1e140e60fd0cb7653a0bc6ec648fc) may be helpful to you as well. 

## Creating an uber jar of ml-gradle

If you'd prefer to have a single jar containing all ml-gradle dependency classes, as opposed to a zip or tar of all the dependency jars, toss the following into a build.gradle file:

```
plugins {
	id "java"
}

repositories {
	mavenCentral()
}

dependencies {
	compile "com.marklogic:ml-gradle:4.5.0"
}

jar {
	from {
		configurations.compile.collect { it.isDirectory() ? it : zipTree(it) }
	}
}
```

Then run:

    gradle jar

This will produce an uber jar under ./build/libs. You can then copy that to another project and reference it in that project's build.gradle file:

```
buildscript {
	dependencies {
		classpath fileTree(dir: "path/to/uber-jar-directory", include: "*.jar")
	}
}
apply plugin: "com.marklogic.ml-gradle"
```