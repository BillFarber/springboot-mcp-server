If you're deploying your application to an ML host running in a Docker container, you may run into connection issues like this, particularly when loading modules:

```
Error occurred while loading modules; host: localhost; port: 8013; cause: java.io.IOException: unexpected end of stream on 
Connection{localhost:8013, proxy=DIRECT hostAddress=localhost/0:0:0:0:0:0:0:1:8013 cipherSuite=none protocol=http/1.1}
com.marklogic.client.MarkLogicIOException: java.io.IOException: unexpected end of stream on Connection{localhost:8013, proxy=DIRECT 
hostAddress=localhost/0:0:0:0:0:0:0:1:8013 cipherSuite=none protocol=http/1.1}
```

The most likely cause of this is that the Docker container has not been assigned enough memory, and the container either restarts or momentarily drops connections. The solution is to increase the amount of memory assigned to Docker. At least on a Mac, you can do this via Docker -> Preferences -> Resources. Typically, at least 8gb of memory is a suitable amount to avoid these issues. 