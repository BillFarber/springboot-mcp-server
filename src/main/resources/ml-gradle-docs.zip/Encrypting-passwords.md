It is common to have multiple passwords in your gradle.properties file when using ml-gradle, as there are multiple MarkLogic users that you may need to configure (see [[Property Reference]] for a list of the various user roles). 

Instead of storing these passwords in plaintext in gradle.properties though, you may want to retrieve them from a location where they're encrypted. A common solution for this with Gradle is to use [this Gradle credentials plugin](https://github.com/etiennestuder/gradle-credentials-plugin) for storing and retrieving encrypted credentials. [Googling on "gradle encrypted passwords"](https://www.google.com/search?q=gradle+encrypted+passwords) will return some other solutions too. 

## Using the Gradle credentials plugin

Typically in a Gradle project, you define properties in gradle.properties. But with the credentials plugin, you need to populate your properties in a Gradle "ext" block via the "credentials" object that's added by the credentials plugin. The one trick with ml-gradle is that when the ml-gradle plugin is applied (and before any "ext" blocks are processed), ml-gradle has already created connections to the Admin and Manage app servers. So in addition to populating password properties, we also need to re-initialize those connections.

First, let's assume that the value that would normally be assigned to "mlPassword" is instead being managed via the credentials plugin under the key "myPassword":

    gradle addCredentials --key myPassword --value somePassword

Next, remove "mlPassword" from any gradle*.properties files, as you no longer want it set in plaintext. 

Then, add the following block to your build.gradle file:

    ext {
      // Configure properties based on encrypted credentials
      mlManageConfig.password = credentials.myPassword
      mlManageConfig.securityPassword = credentials.myPassword // only needed if setting mlSecurityUsername
      mlAdminConfig.password = credentials.myPassword
      mlAppConfig.restAdminPassword = credentials.myPassword
      mlAppConfig.appServicesPassword = credentials.myPassword

      // Re-initialize the connections to the Admin and Manage servers
      mlManageClient.manageConfig = mlManageConfig
      mlAdminManager.adminConfig = mlAdminConfig
    }

Now, when any Gradle task is run, the ml-gradle password properties (stored in the mlManageConfig, mlAdminConfig, and mlAppConfig objects that are referenced above) will be set based on values in the credentials plugin, and the connections to the Admin and Manage servers will be created using these passwords. 

## Data Hub note

If you are attempting to use the Gradle credentials plugin on a [Data Hub project](https://github.com/marklogic/marklogic-data-hub), and you're using version 5.2.0 or higher, you'll need to add the following line to the "ext" block:

    hubConfig.mlPassword = credentials.myPassword

You may also need the following to ensure that DHF is using the `ManageClient` and `AdminManager` instances with the updated password:

    hubConfig.manageClient = mlManageClient
    hubConfig.adminManager = mlAdminManager

This should work in version 5.1.0 of Data Hub as well, and possibly version 5.0.0. Also note this is not guaranteed to work, as ml-gradle does not have any knowledge of the Data Hub software. This is just included as a tip in case you arrived here trying to figure out how to use the Gradle credentials plugin with Data Hub. 

