To generate Eclipse files, just run `gradle eclipse`. This task is provided by the Eclipse plugin, which is loaded via:

    apply plugin: 'eclipse'

Running this task will update your Eclipse project files - .project and .classpath - and in doing so, this will also refresh all of your dependencies, if there are any new ones to download. Thus, this is often a handy task for when you simply want to refresh dependencies, ensuring you have the latest ones, without actually doing something that modifies your MarkLogic instance. 