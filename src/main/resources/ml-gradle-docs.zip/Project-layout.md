By default, an ml-gradle project expects for files to be located in MarkLogic-specific directories consistent with the [Maven standard layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html). Those directories are:

- src/main/ml-config = Contains XML/JSON files for resources that an application needs deployed to MarkLogic (e.g. databases, users, roles, app servers). See the [[Resource reference]] for a complete list of supported resource types and their location under this directory.
- src/main/ml-data = Added in release 3.13.0 as a simple mechanism for loading data into a content database. See [[Loading data]] for more information.
- src/main/ml-modules = Contains files that should be loaded into an application's modules database. See [[How modules are loaded]] for more details. 
- src/main/ml-plugins = Contains directories of system plugins; added in 3.13.0. See [[Installing plugins]] for more information.
- src/main/ml-schemas = Contains files that should be loaded into an application's schemas database. See [[Loading schemas]] for more details, which includes new support in 3.11.0 for loading schemas from database-specific paths. 

So a typical ml-gradle project with some basic resources and modules looks like this:

```
project_root
│       build.gradle
│       gradle.properties
└───src
    └───main
        ├───ml-config
        │   │   rest-api.json
        │   ├───databases
        │   │       content-database.json
        │   │
        │   └───security
        │       ├───roles
        │       │       my-app-role.json
        │       │
        │       └───users
        │               my-app-user.json
        │
        ├───ml-data
        │   └───any-path
        │           document1.json
        │           document2.xml
        │
        ├───ml-modules
        │   ├───options
        │   │       my-json-search-options.json
        │   │       my-xml-search-options.xml
        │   │
        │   ├───root
        │   │       my-javascript-module.sjs
        │   │       my-xquery-module.xqy
        │   │
        │   ├───services
        │   │       my-javascript-service.sjs
        │   │       my-xquery-service.xqy
        │   │
        │   └───transforms
        │           my-javascript-transform.sjs
        │           my-xslt-transform.xsl
        │           my-xquery-transform.xqy
        │
        ├───ml-plugins
        │   └───my-plugin
        │           Makefile
        │           my-plugin-code.cpp
        │
        └───ml-schemas
                my-template.json
```

An application is deployed by running mlDeploy. This will deploy all of the artifacts defined in these 3 directories. The [[Task reference]] defines tasks for deploying a specific resource type from ml-config, or for only deploying modules or schemas. 

It's also typical for an ml-gradle project to use the [Gradle properties plugin](https://github.com/stevesaliman/gradle-properties-plugin), and thus the project directory often has additional gradle-*.properties files:

```
project_root
│       build.gradle
│       gradle.properties
│       gradle-dev.properties
│       gradle-local.properties
│       gradle-qa.properties
│       gradle-prod.properties
```

## Database-specific resources

Some resources are deployed into a specific database, such as alert configs, temporal axes, and triggers. As described in the [ml-app-deployer documentation for database-specific resources](https://github.com/marklogic-community/ml-app-deployer/wiki/Deploying-resources-to-databases), version 2.9.0 of ml-gradle added support for deploying these resources to any database and not just the default content database defined by "databases/content-database.json". The databases directory can then have additional directories below it, each named after a database, with resource-specific directories under each of those:

```
databases
│       content-database.json
│       other-database.json
|       another-database.json
└───other-database
    └───alert
        ├───configs
        |       my-config.json
└───another-database
    └───view-schemas
            my-schema.json
```

Version 3.7.0 of ml-gradle/ml-app-deployer adds support for deploying triggers to any triggers database, allowing for a setup like this (in this example, the name of the folder under "databases" is the name of the triggers database):

```
databases
│       content-database.json
│       other-database.json
│       other-triggers-database.json
└───other-triggers-database
    └───triggers
            my-trigger.json
```

Version 3.11.0 of ml-gradle/ml-app-deployer adds support for deploying schemas to any schemas database, via the same pattern as above (and in this case, the name of the folder is that of the schemas database):

```
databases
│       content-database.json
│       my-schemas-database.json
└───my-schemas-database
    └───schemas
            my-schema.xsd
```

Version 3.16.0 provides an alternate mechanism for when the name of the database isn't known at build time. Please see the [ml-app-deployer docs](https://github.com/marklogic-community/ml-app-deployer/wiki/Deploying-resources-to-databases) for more information. 
