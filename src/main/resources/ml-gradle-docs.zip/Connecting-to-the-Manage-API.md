ml-gradle uses the [ml-app-deployer](https://github.com/marklogic-community/ml-app-deployer) library to interact with the MarkLogic Manage API. Spring's [RestTemplate](https://docs.spring.io/spring/docs/current/javadoc-api/org/springframework/web/client/RestTemplate.html) is used by ml-app-deployer to connect to the Manage API. 

The [[Property reference]] page defines all of the properties that are used to configure this connection. But if those properties don't cover your use case - for example, you may need to use Kerberos to authenticate with the Manage API - you can provide your own instance of RestTemplate.

## Using your own instance of RestTemplate

When the ml-gradle plugin is applied, an instance of [ManageClient](https://github.com/marklogic-community/ml-app-deployer/blob/master/src/main/java/com/marklogic/mgmt/ManageClient.java) is created and assigned a Gradle property name of "mlManageClient". So after ml-gradle is applied, you can use a Gradle ext block to overwrite the RestTemplate that is used by mlManageClient:

    ext {
      def myRestTemplate = do whatever you need to do here
      mlManageClient.setRestTemplate(myRestTemplate)
    }

ManageClient can also have two instances of RestTemplate, in case you're using one MarkLogic user for the Manage API calls that require the "security" role and a separate user for the calls that do not require the "security" role. If you're doing that, you'll most likely need to override both RestTemplate's:

    ext {
      def myRestTemplate = do whatever you need to do here
      mlManageClient.setRestTemplate(myRestTemplate)
      mlManageClient.setSecurityRestTemplate(myRestTemplate)
    }

As for how to create a RestTemplate - see the Spring docs for that and/or google on the specific thing you're trying to do. For example, if you need to use Kerberos, the [KerberosRestTemplate](https://docs.spring.io/spring-security-kerberos/docs/current/reference/html/ssk-resttemplate.html) may be the right choice for you.
