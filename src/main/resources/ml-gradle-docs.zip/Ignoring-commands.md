As of version 2.9.0, when you run mlDeploy, you can ignore one or more commands that are executed by mlDeploy. mlDeploy executes a sequence of command classes defined in the ml-app-deployer project. To ignore one of these while running mlDeploy, just reference the short (no package) class name of one or more commands, separated by commas:

    gradle mlDeploy -Pignore=DeployRolesCommand,DeployTriggersCommand

ml-gradle will then log when it ignores a command:

    Ignoring command: DeployRolesCommand

