The tables below show all available properties for configuring ml-gradle as of version 3.6.1. This page is based on the 
[factory class in ml-app-deployer](https://github.com/marklogic-community/ml-app-deployer/blob/master/src/main/java/com/marklogic/appdeployer/DefaultAppConfigFactory.java) that reads properties from a property source object (the PropertySource interface exists to hide where the properties come from - in ml-gradle, they come from the Gradle Project class, whereas in other environments, using system properties or a java.util.Properties may be desired).

Note that if you're just interested in what MarkLogic server ports are used by ml-gradle, see the [[Port reference]]. 

# General properties

These properties are used by a variety of tasks and commands. 

| Property  | Description |
| --- | --- |
| mlAppName | Application name that is used as a prefix for creating a variety of resources when mlNoRestServer is not set to false, such as a REST API server and a content database. Default value is "my-app". |
| mlCatchDeployExceptions | New in 3.2.0 - set to true so that any command that fails when the mlDeploy task is run catches and logs an exception instead of failing the task. Defaults to false. |
| mlCatchUndeployExceptions | New in 3.2.0 - set to true so that any command that fails when the mlUndeploy task is run catches and logs an exception instead of failing the task. Defaults to false. |
| mlIgnoreProjectDir | New in 3.12.0 - starting in 3.12.0, to support using ml-gradle with Java 11 and the Gradle daemon, all file paths are constructed relative to the Gradle projectDir property. This avoids a problem where paths are constructed relative to the directory that the Gradle daemon runs in. However, if you want to use absolute paths for properties like mlModulePaths, mlConfigPaths, and mlSchemaPaths, you should set this property to true so that your paths are not made relative to the project directory. Defaults to false. |
| mlPropsAsTokens | New in 3.2.0 - set to true for all Gradle properties to be included as tokens with a default prefix and suffix of "%%". See [[Configuring resources]] for more information. Defaults to true, which means this behavior is enabled by default. Can be set to "false" to disable it. |
| mlTokenPrefix | New in 3.2.0 - when mlPropsAsTokens is set to true, the default prefix is "%%". Set this property to override that prefix. No default value. |
| mlTokenSuffix | New in 3.2.0 - when mlPropsAsTokens is set to true, the default suffix is "%%". Set this property to override that suffix. No default value. |

# Properties affecting every connection

The following properties will affect the 4 connections that ml-gradle may make - to the App-Services app server, the Admin app server, the Manage app server, and an application's REST API app server (if one is configured via `mlRestPort`).

| Property  | Description |
| --- | --- |
| mlAuthentication | New in 4.5.0 - if set, will also set the values of `mlManageAuthentication`, `mlAdminAuthentication`, `mlAppServicesAuthentication`, and `mlRestAuthentication` (and each of those, if set, will override this property's value). No default value. |
| mlCloudApiKey| New in 4.5.0 - the API key required by a MarkLogic Cloud instance. If set, then port 443 will be used for all connections to Marklogic. |
| mlCloudBasePath | New in 4.5.0 - the common portion of all base paths for a MarkLogic Cloud instance. If set, this will result in default values being set for `mlManageBasePath`, `mlAdminBasePath`, and `mlAppServicesBasePath`. In addition, if `mlRestBasePath` and/or `mlTestRestBasePath` are set, this value will be prepended to those property values. No default value. |
| mlHost | The MarkLogic host that requests should be sent to. Defaults to localhost. |
| mlKeyStorePath | New in 4.7.0 - file path of a Java key store to be used for two-way SSL. |
| mlKeyStorePassword | New in 4.7.0 - optional password for the Java key store. |
| mlKeyStoreType | New in 4.7.0 - the Java key store type; defaults to "JKS". |
| mlKeyStoreAlgorithm | New in 4.7.0 - the Java key store algorithm; defaults to "SunX509". |
| mlPassword | The password for the user defined by mlUsername. Defaults to admin. Depending on the task, can be overridden by mlRestAdminPassword, mlManagePassword, mlAppServicesPassword, or mlSecurityPassword. |
| mlSslHostnameVerifier | New in 4.5.0 - if set, will also set the values of `mlManageSslHostnameVerifier`, `mlAdminSslHostnameVerifier`, `mlAppServicesHostnameVerifier`, and `mlRestSslHostnameVerifier`. Must be one of `any`, `common`, or `strict`. No default value. |
| mlTrustStorePath | New in 4.7.0 - file path of a Java trust store to be used for establishing trust with a MarkLogic app server. |
| mlTrustStorePassword | New in 4.7.0 - optional password for the Java trust store. |
| mlTrustStoreType | New in 4.7.0 - the Java trust store type; defaults to "JKS". |
| mlTrustStoreAlgorithm | New in 4.7.0 - the Java trust store algorithm; defaults to "SunX509". |
| mlUsername | The default MarkLogic username for any call to MarkLogic. Defaults to admin. Depending on the task, can be overridden by mlRestAdminUsername, mlManageUsername, mlAppServicesUsername, or mlSecurityUsername. |

# Manage server connection properties

These properties are used for connecting to the Manage app server that by default is on port 8002.

See [[Configuring security]] for more information on how mlManageUsername and mlSecurityUsername are utilized. And see [[Connecting to the Manage API]] for more information on how to control this connection. 

| Property  | Description |
| --- | --- |
| mlManageAuthentication | New in 4.5.0 - defines which authentication strategy to use. Defaults to `digest`. Can be `basic`, `certificate`, `cloud`, `digest`, `kerberos`, or `saml`. |
| mlManageBasePath | New in 4.5.0 - when connecting to a MarkLogic Cloud instance, this is the base path associated with the Manage app server |
| mlManageCertFile | New in 4.5.0 - defines the certificate file to use when mlManageAuthentication is set to `certificate`. |
| mlManageCertPassword | New in 4.5.0 - defines the certificate file password to use when mlManageAuthentication is set to `certificate`. |
| mlManageCleanJsonPayloads | New in 3.1.0 - when set to true, ml-gradle will "clean" every JSON payload it sends to the Management API, thus removing any comments which are allowed by the underlying [Jackson](https://github.com/FasterXML/jackson-docs) library, but not allowed by the Management API. Defaults to false, as there's some overhead with doing this, and many projects may not wish to allow comments in their JSON payload files. |
| mlManageExternalName | New in 4.5.0 - defines the external name to use when mlManageAuthentication is set to `kerberos`. |
| mlManageHost | Specifies the host to connect to for Manage API operations. If not specified, mlHost is used. No default value. |
| mlManageKeyStorePath | New in 4.7.0 - file path of a Java key store to be used for two-way SSL. |
| mlManageKeyStorePassword | New in 4.7.0 - optional password for the Java key store. |
| mlManageKeyStoreType | New in 4.7.0 - the Java key store type; defaults to "JKS". |
| mlManageKeyStoreAlgorithm | New in 4.7.0 - the Java key store algorithm; defaults to "SunX509". |
| mlManagePassword | Password for the user specified by mlManageUsername. Defaults to the value of mlUsername if not specified. |
| mlManagePort | Specifies the port for the Manage server in MarkLogic. Defaults to 8002. |
| mlManageSamlToken | New in 4.5.0 - specify a [SAML token](https://docs.marklogic.com/guide/java/intro#id_64103) when mlManageAuthentication is set to `saml`. |
| mlManageScheme | New in 2.7.0 - specifies the scheme - http or https - to use when connecting to the Manage server. Defaults to http. |
| mlManageSimpleSsl | New in 3.0.0 - use a simple SSL context when connecting to the Manage server. Defaults to false. |
| mlManageSslHostnameVerifier | New in 4.5.0 - specify an SSL hostname verification strategy; must be one of `any`, `common`, or `strict`. No default value. |
| mlManageSslProtocol | New in 3.17.0 - specify the protocol to use for SSL connections. No default value (but as of this version, TLSv1.2 is used by default). |
| mlManageTrustManagementAlgorithm | When setting mlManageUseDefaultKeystore to true, can set this in case the JVM's default algorithm (likely PKIX) - is not correct for your JVM's default keystore. No default value. |
| mlManageTrustStorePath | New in 4.7.0 - file path of a Java trust store to be used for establishing trust with a MarkLogic app server. |
| mlManageTrustStorePassword | New in 4.7.0 - optional password for the Java trust store. |
| mlManageTrustStoreType | New in 4.7.0 - the Java trust store type; defaults to "JKS". |
| mlManageTrustStoreAlgorithm | New in 4.7.0 - the Java trust store algorithm; defaults to "SunX509". |
| mlManageUseDefaultKeystore | New in 3.17.0 - instead of using a trust-everything approach with mlManageSimpleSsl, set this to true to use the JVM's default keystore for determining whether to trust a server certificate or not. Defaults to false. |
| mlManageUsername | MarkLogic user for operations that require the MarkLogic "manage-admin" role. Used for all Management API operations except those that require the security role; mlSecurityUsername is used for those (see that property for more information). Defaults to the value of mlUsername if not specified. |
| mlSecurityPassword | New in 3.4.0, replacing the user of mlAdminPassword for the same purpose - password for the user identified by mlSecurityUsername. Defaults to the value of mlManagePassword if not specified. |
| mlSecurityUsername | New in 3.4.0, replacing the use of mlAdminUsername for the same purpose - MarkLogic user that has both the "manage-admin" and "security" roles. Defaults to the value of mlManageUsername if not specified. |

# Admin server connection properties

These properties are used for connecting to the Admin server that by default is on port 8001. [Some Manage API endpoints](http://docs.marklogic.com/REST/management/admin) are exposed on port 8001 instead of port 8002. 

| Property  | Description |
| --- | --- |
| mlAdminAuthentication | New in 4.5.0 - defines which authentication strategy to use. Defaults to `digest`. Can be `basic`, `certificate`, `cloud`, `digest`, `kerberos`, or `saml`. |
| mlAdminBasePath | New in 4.5.0 - when connecting to a MarkLogic Cloud instance, this is the base path associated with the Admin app server |
| mlAdminCertFile | New in 4.5.0 - defines the certificate file to use when mlAdminAuthentication is set to `certificate`. |
| mlAdminCertPassword | New in 4.5.0 - defines the certificate file password to use when mlAdminAuthentication is set to `certificate`. |
| mlAdminExternalName | New in 4.5.0 - defines the external name to use when mlAdminAuthentication is set to `kerberos`. |
| mlAdminHost | Specifies the host to connect to for admin-required operations. Defaults to the value of mlHost. |
| mlAdminKeyStorePath | New in 4.7.0 - file path of a Java key store to be used for two-way SSL. |
| mlAdminKeyStorePassword | New in 4.7.0 - optional password for the Java key store. |
| mlAdminKeyStoreType | New in 4.7.0 - the Java key store type; defaults to "JKS". |
| mlAdminKeyStoreAlgorithm | New in 4.7.0 - the Java key store algorithm; defaults to "SunX509". |
| mlAdminPassword | Deprecated in 3.4.0, and removed in 4.0.0 - Password for the user specified by mlAdminUsername. Defaults to the value of mlPassword. In 3.4.0 and later, mlManagePassword is used, since the user identified by mlManageUsername should suffice for invoking every Manage endpoint on 8001. |
| mlAdminPort | Specifies the port for the Admin server in MarkLogic. Defaults to 8001. |
| mlAdminSamlToken | New in 4.5.0 - specify a [SAML token](https://docs.marklogic.com/guide/java/intro#id_64103) when mlAdminAuthentication is set to `saml`. |
| mlAdminScheme | New in 2.7.0 - specifies the scheme - http or https - to use when connecting to the Admin server. Defaults to http. |
| mlAdminSimpleSsl | New in 3.0.0 - use a simple SSL context when connecting to the Admin server. Defaults to false. |
| mlAdminSslHostnameVerifier | New in 4.5.0 - specify an SSL hostname verification strategy; must be one of `any`, `common`, or `strict`. No default value. |
| mlAdminSslProtocol | New in 3.17.0 - specify the protocol to use for SSL connections. No default value (but as of this version, TLSv1.2 is used by default). |
| mlAdminTrustManagementAlgorithm | When setting mlAdminUseDefaultKeystore to true, can set this in case the JVM's default algorithm (likely PKIX) - is not correct for your JVM's default keystore. No default value. |
| mlAdminTrustStorePath | New in 4.7.0 - file path of a Java trust store to be used for establishing trust with a MarkLogic app server. |
| mlAdminTrustStorePassword | New in 4.7.0 - optional password for the Java trust store. |
| mlAdminTrustStoreType | New in 4.7.0 - the Java trust store type; defaults to "JKS". |
| mlAdminTrustStoreAlgorithm | New in 4.7.0 - the Java trust store algorithm; defaults to "SunX509". |
| mlAdminUseDefaultKeystore | New in 3.17.0 - instead of using a trust-everything approach with mlAdminSimpleSsl, set this to true to use the JVM's default keystore for determining whether to trust a server certificate or not. Defaults to false. |
| mlAdminUsername | Deprecated in 3.4.0, and removed in 4.0.0 - MarkLogic user for connecting to the Admin server on port 8001. In 3.4.0 and later, mlManageUsername is used, since that user should suffice for invoking every Manage endpoint on 8001. |

# App-Services server connection properties

These properties are used for connecting to the App-Services server that by default is on port 8000. The App-Services server is used whenever files should be loaded as documents into a particular database. This includes [[how modules are loaded]], [[loading schemas]], and [[loading data]]. 

| Property  | Description |
| --- | --- |
| mlAppServicesAuthentication | New in 3.0.0 - define which authentication strategy to use when connecting to the App-Services server. Defaults to `digest`. Can be `basic`, `certificate`, `cloud`, `digest`, `kerberos`, or `saml`. |
| mlAppServicesBasePath | New in 4.5.0 - when connecting to a MarkLogic Cloud instance, this is the base path associated with the App-Services app server |
| mlAppServicesCertFile | New in 3.0.0 - defines the certificate file to use when mlAppServicesAuthentication is set to `certificate`. |
| mlAppServicesCertPassword | New in 3.0.0 - defines the certificate file password to use when mlAppServicesAuthentication is set to `certificate`. |
| mlAppServicesConnectionType | New in 3.14.0 - defines the connection type for any DatabaseClient that connects to the App-Services server. Can be `DIRECT` or `GATEWAY`. No default value. |
| mlAppServicesExternalName | New in 3.0.0 - defines the external name to use when mlAppServicesAuthentication is set to `kerberos`. |
| mlAppServicesKeyStorePath | New in 4.7.0 - file path of a Java key store to be used for two-way SSL. |
| mlAppServicesKeyStorePassword | New in 4.7.0 - optional password for the Java key store. |
| mlAppServicesKeyStoreType | New in 4.7.0 - the Java key store type; defaults to "JKS". |
| mlAppServicesKeyStoreAlgorithm | New in 4.7.0 - the Java key store algorithm; defaults to "SunX509". |
| mlAppServicesPassword | Password for the user specified by mlAppServicesUsername. Defaults to the value of mlPassword. |
| mlAppServicesPort | Specifies the port for the App-Services server in MarkLogic. Used for loading modules (normally via the ML /v1/documents endpoint, but via XCC in older versions of ml-gradle). Defaults to 8000. |
| mlAppServicesSamlToken | New in 4.5.0 - specify a [SAML token](https://docs.marklogic.com/guide/java/intro#id_64103) when mlAppServicesAuthentication is set to `saml`. |
| mlAppServicesSimpleSsl | New in 3.0.0 - Set to "true" to use a simple SSL connection (a simple SSL context and the "ANY" hostname verifier) when connecting to the App-Services server. Starting 3.16.0, you can also set this to any value besides "true" or "false" to specify a particular protocol; TLSv1.2 is the default with 3.16.0. See [Loading modules via SSL](https://github.com/marklogic-community/ml-gradle/wiki/Loading-modules-via-SSL) for more information on configuring an SSL connection. No default value. |
| mlAppServicesSslHostnameVerifier | New in 4.5.0 - specify an SSL hostname verification strategy; must be one of `any`, `common`, or `strict`. No default value. |
| mlAppServicesSslProtocol | New in 3.17.0 - specify the protocol to use for SSL connections. No default value (but as of this version, TLSv1.2 is used by default). |
| mlAppServicesTrustManagementAlgorithm | When setting mlAppServicesUseDefaultKeystore to true, can set this in case the JVM's default algorithm (likely PKIX) - is not correct for your JVM's default keystore. No default value. |
| mlAppServicesTrustStorePath | New in 4.7.0 - file path of a Java trust store to be used for establishing trust with a MarkLogic app server. |
| mlAppServicesTrustStorePassword | New in 4.7.0 - optional password for the Java trust store. |
| mlAppServicesTrustStoreType | New in 4.7.0 - the Java trust store type; defaults to "JKS". |
| mlAppServicesTrustStoreAlgorithm | New in 4.7.0 - the Java trust store algorithm; defaults to "SunX509". |
| mlAppServicesUseDefaultKeystore | New in 3.17.0 - instead of using a trust-everything approach with mlAppServicesSimpleSsl, set this to true to use the JVM's default keystore for determining whether to trust a server certificate or not. Defaults to false. |
| mlAppServicesUsername | MarkLogic user for connecting to the App-Services server. Defaults to the value of mlUsername. |

# REST API server connection properties

If your application has a REST API server, these properties are used to connect to it, most often for loading REST API modules such as options, services, and transforms.

Note that when a REST API server is created, it defaults to `digest` for authentication. If you intend to use a different authentication strategy, you'll need to set both the mlRestAuthentication property defined below, and you'll need to configure the REST server to use the matching authentication strategy. This is typically done via the "./servers/rest-api-server.json" in your configuration directory, as this resource file is used to update both the REST server associated with mlRestPort and the one associated with mlTestRestPort, in case you've set that to a value greater than zero (thus creating a test REST server and database). See the [rest-api-server.json file in this sample project](https://github.com/marklogic-community/ml-gradle/blob/master/examples/sample-project/src/main/ml-config/servers) for an example. 

| Property  | Description |
| --- | --- |
| mlRestAdminUsername | MarkLogic user for operations involving a client REST API, such as loading modules. Defaults to the value of mlUsername. |
| mlRestAdminPassword | Password for the user specified by mlRestAdminUsername. Defaults to the value of mlPassword. |
| mlRestAuthentication | Introduced in 2.7.0, but altered slightly in 3.0.0. Prior to 3.0.0, this is used to choose an authentication as defined by the Java Client API's Authentication class. In version 4.x of marklogic-client-api, the Authentication class is deprecated. This property can still be used the same way it's used in 2.7.0, but it will map to the SecurityContextType enum defined in the ml-javaclient-util module. The purpose is the same - define which authentication strategy you want to use. Defaults to "digest". Can be `basic`, `certificate`, `cloud`, `digest`, `kerberos`, or `saml`. |
| mlRestBasePath | New in 4.5.0 - when connecting to a MarkLogic Cloud instance, this is the base path associated with the REST API app server associated with mlRestPort.|
| mlRestCertFile | New in 3.0.0 - defines the certificate file to use when mlRestAuthentication is set to `certificate`. |
| mlRestCertPassword | New in 3.0.0 - defines the certificate file password to use when mlRestAuthentication is set to `certificate`. |
| mlRestConnectionType | New in 3.14.0 - defines the connection type. Can be `DIRECT` or `GATEWAY`. No default value. |
| mlRestExternalName | New in 3.0.0 - defines the external name to use when mlRestAuthentication is set to `kerberos`. |
| mlRestKeyStorePath | New in 4.7.0 - file path of a Java key store to be used for two-way SSL. |
| mlRestKeyStorePassword | New in 4.7.0 - optional password for the Java key store. |
| mlRestKeyStoreType | New in 4.7.0 - the Java key store type; defaults to "JKS". |
| mlRestKeyStoreAlgorithm | New in 4.7.0 - the Java key store algorithm; defaults to "SunX509". |
| mlRestPort | If a REST API server is created by default (will be unless mlNoRestServer is set to true), this port number is used for it. No default value. Starting in 4.5.0, if mlCloudApiKey is set, this property will only be used for creating a REST API server, and 443 will be used for connecting to that REST API server. |
| mlRestSamlToken | New in 4.5.0 - specify a [SAML token](https://docs.marklogic.com/guide/java/intro#id_64103) when mlRestAuthentication is set to `saml`. |
| mlRestSslHostnameVerifier | New in 4.5.0 - specify an SSL hostname verification strategy; must be one of `any`, `common`, or `strict`. No default value. |
| mlRestSslProtocol | New in 3.17.0 - specify the protocol to use for SSL connections. No default value (but as of 3.16.0, TLSv1.2 is used by default when no value is specified). |
| mlRestTrustManagementAlgorithm | When setting mlRestUseDefaultKeystore to true, can set this in case the JVM's default algorithm (likely PKIX) - is not correct for your JVM's default keystore. No default value. |
| mlRestTrustStorePath | New in 4.7.0 - file path of a Java trust store to be used for establishing trust with a MarkLogic app server. |
| mlRestTrustStorePassword | New in 4.7.0 - optional password for the Java trust store. |
| mlRestTrustStoreType | New in 4.7.0 - the Java trust store type; defaults to "JKS". |
| mlRestTrustStoreAlgorithm | New in 4.7.0 - the Java trust store algorithm; defaults to "SunX509". |
| mlRestUseDefaultKeystore | New in 3.17.0 - instead of using a trust-everything approach with mlSimpleSsl, set this to true to use the JVM's default keystore for determining whether to trust a server certificate or not. Defaults to false. |
| mlSimpleSsl | When modules are loaded via the Client REST API, if the app server requires an SSL connection, then setting this property to "true" will force a simple SSL connection to be created (a simple SSL context and 'ANY' hostname verifier). Starting 3.16.0, you can also set this to any value besides "true" or "false" to specify a particular protocol; TLSv1.2 is the default with 3.16.0. No default value. |

# CMA properties

The [Configuration Management API](http://docs.marklogic.com/REST/configuration-management-api) (CMA) is used by ml-gradle to speed up the deployment of certain resources. See the [ml-app-deployer docs](https://github.com/marklogic-community/ml-app-deployer/wiki/Configuration-Management-API) for more information, including a list of properties for configuring CMA usage. 

# Data properties

Version 3.13.0 added support for loading data as part of a deployment. See [[Loading data]] for more information, along with the [ml-app-deployer docs](https://github.com/marklogic-community/ml-app-deployer/wiki/Loading-data) for a list of properties. 

# Database and forest properties

These properties specify how databases and forests (including replicas) are created. See [[Creating forests]] for more information. 

| Property  | Description |
| --- | --- |
| mlContentDatabaseName | When a REST API server is created, the content database name will default to "(mlAppName)-content". This property can be used to override that name. No default value. |
| mlContentForestsPerHost | When a content database is created, specifies the number of forests per host for it. Prior to 3.12.0, this was only applied when the database is created via the databases/content-database.json file. Starting with 3.12.0, it's also applied when a REST API instance is created and no content-database.json file exists. Note that this only impacts the database identified by the content-database.json file, if it exists. If you don't have such a file, or aren't sure, just use mlForestsPerHost, which works for any database. Defaults to 3. |
| mlCpfDatabaseName | New in 3.5.0 - when CPF resources are deployed, they by default are deployed to the value of mlTriggersDatabaseName, which defaults to "(mlAppName)-triggers". This property can be used to override the database name. No default value. |
| mlCreateForests | New in 3.1.0 - when a database is created, this controls whether ml-gradle tries to create forests for it or not. Defaults to true. Setting this to false is useful for when you only want to update a database's settings. |
| mlDatabaseGroups | New in 3.3.0 - set the groups whose hosts forests should be created on for specific databases. This is a double-delimited string of the form "database-name1,group1\|group2,database-name2,group2\|group3\|group4". This takes precedence over mlDatabaseHosts; if an entry exists for a database in both properties, it will be ignored in mlDatabaseHosts, with a warning message logged. No default value. |
| mlDatabaseHosts | New in 3.2.0 - set the hosts that forests are created on for specific databases. This a double-delimited string of the form "database-name1,host1\|host2,database-name2,host2\|host3\|host4". This is useful for when you don't want forests on certain hosts, such as when you have separate E and D nodes. No default value. |
| mlDatabaseDataDirectories | New in 3.2.0 - comma-delimited string of database names and forest data directories. Overrides the database-agnostic value specified by mlForestDataDirectory. New in 3.7.0 - you can specify multiple data directories using a double-delimited string, similar to mlDatabaseGroups - e.g. "database-name1,/dir1/dir2/dir3".  |
| mlDatabaseFastDataDirectories | New in 3.2.0 - comma-delimited string of database names and forest fast data directories. Overrides the database-agnostic value specified by mlForestFastDataDirectory. |
| mlDatabaseLargeDataDirectories | New in 3.2.0 - comma-delimited string of database names and forest large data directories. Overrides the database-agnostic value specified by mlForestLargeDataDirectory. |
| mlDatabaseNamesAndReplicaCounts | Comma-delimited string of database names and forest replica counts. Useful for when you want to configure failover for a database, and you may want to use additional properties to configure the directories for each replica forest. No default value. |
| mlDatabasesWithForestsOnOneHost | New in 3.2.0 - comma-delimited string of database names that should only have forests created on one host (and most likely, that's only one forest). Useful for databases like a modules database that have so little content that there's no point in having more than one forest. In 3.11.0, if this is not set, then the default schema and trigger database names will be included. Otherwise, no default value. |
| mlDatabaseReplicaDataDirectories | New in 3.2.0 - comma-delimited string of database names and replica forest data directories. Overrides the database-agnostic value specified by mlReplicaForestDataDirectory. Starting 3.16.0, this accepts multiple pipe-delimited paths, similar to mlDatabaseDataDirectories. |
| mlDatabaseReplicaFastDataDirectories | New in 3.2.0 - comma-delimited string of database names and replica forest fast data directories. Overrides the database-agnostic value specified by mlReplicaForestFastDataDirectory. |
| mlDatabaseReplicaLargeDataDirectories | New in 3.2.0 - comma-delimited string of database names and replica forest large data directories. Overrides the database-agnostic value specified by mlReplicaForestLargeDataDirectory. |
| mlDeleteForests | When a database is deleted via mlUndeploy, controls whether or not forests are deleted. If mlDeleteReplicas is set to true, this has no impact - currently, the forests and their replicas will be deleted together for efficiency reasons (far fewer calls to the Management API). Defaults to true. |
| mlDeleteReplicas | When a database is deleted via mlUndeploy, controls whether primary forests and their replicas are deleted first. Most of the time, you want this set to true as otherwise, the database can't be deleted. Defaults to true. |
| mlForestDataDirectory | New in 3.2.0 - defines the default data directory for all forests created by ml-gradle. Can be overridden for a database via mlDatabaseDataDirectories. No default value. |
| mlForestFastDataDirectory | New in 3.2.0 - defines the default fast data directory for all forests created by ml-gradle. Can be overridden for a database via mlDatabaseFastDataDirectories. No default value. |
| mlForestLargeDataDirectory | New in 3.2.0 - defines the default large data directory for all forests created by ml-gradle. Can be overridden for a database via mlDatabaseLargeDataDirectories. No default value. |
| mlForestsPerHost | New in 3.0.0, but could be set in prior versions. Set this to a comma-delimited string of database-name,forest-count,database-name,forest-count,etc. Prior to 3.0.0, you can set this via mlAppConfig.forestCounts.put("database-name-", forestCount) in build.gradle. No default value. |
| mlModulesDatabaseName | When a REST API server is created, the modules database name will default to "(mlAppName)-modules". This property can be used to override that name. No default value. |
| mlOptimizeWithCma | (Intentionally listed here in addition to in the first section) New in 3.8.0 - when using ML 9.0-5 or greater, you can set this to true to optimize the creation of forests via a CMA (Configuration Management API) package. Defaults to false. |
| mlReplicaForestDataDirectory | New in 2.8.0 - set this to define the data-directory of forests created dynamically via mlDatabaseNamesAndReplicaCounts. No default value. |
| mlReplicaForestFastDataDirectory | New in 2.8.0 - set this to define the fast-data-directory of forests created dynamically via mlDatabaseNamesAndReplicaCounts. No default value. |
| mlReplicaForestLargeDataDirectory | New in 2.8.0 - set this to define the large-data-directory of forests created dynamically via mlDatabaseNamesAndReplicaCounts. No default value. |
| mlSchemasDatabaseName | New in 3.0.0 - ml-gradle defines a default token of "%%SCHEMAS_DATABASE%%" that will be replaced in payload files. This defaults to "(mlAppName)-schemas". This property can be used to override that value. No default value. |
| mlTriggersDatabaseName | Defines the name of the triggers database that is assumed to be attached to the content database. Defaults to "(mlAppName)-triggers". |


# Other resource properties

These properties specify how resources not covered above are to be deployed. 

| Property  | Description |
| --- | --- |
| mlAddHostNameTokens | New in 3.13.0 - see the [scheduled task docs](https://github.com/marklogic-community/ml-app-deployer/wiki/Scheduled-Tasks) for more information. Note that this property is only processed when deploying resources via mlDeploy or any of the other mlDeploy(resource type) tasks. Defaults to false. |
| mlCascadeCollections | New in 4.6.0; if set to `true`, then the values in `collections.properties` files will be applied to child directories, unless a child directory has its own file. Applies to load data, modules, and schemas. Defaults to `false` for backwards compatibility with previous releases. |
| mlCascadePermissions | New in 4.6.0; if set to `true`, then the values in `permissions.properties` files will be applied to child directories, unless a child directory has its own file. Applies to load data, modules, and schemas. Defaults to `false` for backwards compatibility with previous releases. |
| mlConfigDir | Deprecated in 3.x, removed in 4.0.0, use mlConfigPath or mlConfigPaths. |
| mlConfigPath | Path to the parent directory containing all of the configuration directories. Defaults to src/main/ml-config. |
| mlConfigPaths | New in 3.3.0 - allows for setting multiple paths for configuration directories. Useful for when you want to have environment-specific resources. If this is set, then mlConfigDir and mlConfigPath will be ignored (there's no reason to set either if mlConfigPaths is set). If not set, then src/main/ml-config is used as the path to a single configuration directory. |
| mlFlexrepPath | Specifies the path for Flexrep configuration files. No default value for this property, but Flexrep files by default are expected to be found at "(mlConfigPath)/flexrep". |
| mlGroupName | Specifies the group that group-specific resources should be deployed to, such as scheduled tasks and app servers. Default value is "Default". |
| mlHostCertificatePassphrases | New in 5.1.0 - accepts a comma-delimited sequence of private key file base names and passphrase. Please see the host certificate section in the [Resource Reference](https://github.com/marklogic/ml-gradle/wiki/Resource-reference) for more information. |
| mlHostCertificatePassphrasesDelimiter | New in 5.1.0 - configures a different delimiter to be used by `mlHostCertificatePassphrases`. |
| mlHostGroups | New in 3.6.1 - used to assign hosts to groups, where the property value is a comma-delimited string with format "host1,group1,host2,group1,host3,group2". If specified, during mlUndeploy, each specified host will be assigned back to the Default group. No default value. |
| mlNoRestServer | New in 2.7.0 - set this to true so that mlDeploy will not create a REST API server by default. No default value. |
| mlResourceFilenamesToExcludeRegex | New in 3.0.0 - regex that defines resource filenames to exclude from processing (exclude = ignore). Useful for when you want to exclude a set of resources when deploying to a certain environment. Cannot be set when mlResourceFilenamesToIncludeRegex is also set. No default value. |
| mlResourceFilenamesToIgnore | Comma-separated list of resource filenames that should be ignored and not deployed. Useful for when different environments require different resources to be deployed. No default value. |
| mlResourceFilenamesToIncludeRegex | New in 3.0.0 - regex that defines resource filenames to include. If a filename doesn't match this regex, then it will be excluded (ignored). Cannot be set when mlResourceFilenamesToExcludeRegex is also set. No default value. |
| mlRestServerName | New in 3.4.0 - if a REST API server is created by default, this property will override the default name of the REST server, which itself defaults to the value of mlAppName. No default value. |
| mlSortRolesByDependencies | New in 2.9.0 - set this to "true" or "false" for whether ml-gradle should figure out the order for deploying roles by reading each file and looking at the role dependencies. Defaults to true. You can set this to "false" if you already are ordering your roles based on the name of each role file. |
| mlTestContentDatabaseName | New in 3.11.0 - sets the name of the test content database, if created. |
| mlTestRestBasePath | New in 4.5.0 - when connecting to a MarkLogic Cloud instance, this is the base path associated with the REST app server created via mlTestRestPort. |
| mlTestRestPort | If set to above zero, a test REST API server is created using this port number. No default value. Starting in 4.5.0, if mlCloudApiKey is set, this property will only be used for creating a test REST API server, and 443 will be used for connecting to that REST API server. |
| mlTestRestServerName | New in 3.4.0 - if a test REST API server is created by default, this property will override the default name of the test REST server, which itself defaults to the value of "(mlAppName)-test". No default value. |
| mlUpdateMimetypeWhenPropertiesAreEqual | New in 3.8.1 - if a mimetype exists and is being updated but its properties are the same as what's already defined for the mimetype in MarkLogic, then because this defaults to false, no call to the Manage API is made, thus avoiding an unnecessary restart. If this is set to true, then the mimetype is always updated, which will always trigger a restart. Defaults to false. |
|user | Used for task mlExportWorkspaces. The user whose QConsole workspaces you will be exporting. |
|workspaceNames | A comma separated list of existing workspace names that will be exported with the mlExportWorkspaces task |

# Module and schema properties 

These properties specify how modules and schemas should be loaded. 

| Property  | Description |
| --- | --- |
| mlAdditionalBinaryExtensions | Comma-delimited string of extensions for modules that should be loaded as binaries. The [ml-javaclient-util](https://github.com/marklogic-community/ml-javaclient-util) library defines a number of extensions, and this can be used to add more. No default value. Note that these will not override any MIME types registered in MarkLogic, [per the REST API docs](https://docs.marklogic.com/guide/rest-dev/intro#id_53367). |
| mlBulkLoadAssets | Specifies whether or not to load asset modules in bulk - i.e. in one request, which is normally more performant than one request per module. Defaults to true. |
| mlDeleteTestModules | New in 2.9.0 - specifies whether test modules should be deleted or not after modules are loaded. Defaults to false. |
| mlDeleteTestModulesPattern | New in 2.9.0 - specifies the wildcard pattern (used with cts:uri-match) for deleting test modules. Defaults to /test/** |
| mlModulePaths | Comma-separated list of paths for loading modules. Defaults to src/main/ml-modules. |
| mlModulePermissions | Comma-delimited string of role/capability/role/capability/etc that defines permissions for deployed modules. Defaults to rest-admin,read,rest-admin,update,rest-extension-user,execute. |
| mlModulesLoaderBatchSize | New in 3.4.0 - controls the number of asset modules loaded in each call to /v1/documents on the app services port. No default value, which means that all asset modules are loaded in a single call. |
| mlModulesLoaderThreadCount | New in 3.1.0, but changed in 3.10.0 to default to 1 - number of threads to use when loading modules. Prior to 3.10.0, defaults to 8. Setting this 1 makes the modules loading process single threaded - i.e. ml-gradle won't try to load REST API services, transforms, and options in parallel. |
| mlModulesRegex | New in 3.3.0 - when running mlLoadModules or mlReloadModules, only load modules with a file path matching the given regex pattern. No default value. |
| mlModuleTimestampsPath | Specifies the path to the timestamps file that tasks like mlLoadModules and mlWatch use for knowing whether a module file is new or modified so that modules aren't loaded over and over without any changes. Defaults to build/ml-last-configured-timestamps.properties. |
| mlModuleTimestampsUseHost | New in 3.14.0 - specifies whether the host that modules are loaded via should be included in the property keys in the module timestamps file. Defaults to true. |
| mlModuleUriPrefix | New in 4.2.0 - specifies a prefix to be added to the URI of every module loaded; does not apply to REST extensions. |
| mlReplaceTokensInModules | Enables or disables whether tokens will be replaced in module files. This is used to support Roxy-like token substitutions in modules. Also see mlUseRoxyTokenPrefix. Defaults to true. |
| mlSchemaPaths | New in 3.13.0 - comma-delimited list of paths to files that should be loaded into the application's schemas databases. Defaults to src/main/ml-schemas. |
| mlSchemasPath | Deprecated in 3.13.0, removed in 4.0.0 - path to files that should be loaded into the application's schemas database. Defaults to src/main/ml-schemas. |
| mlStaticCheckAssets | Specifies whether or not to statically check asset modules after they're loaded. Defaults to false. |
| mlStaticCheckLibraryAssets | Specifies whether or not to attempt to statically check asset library modules after they're loaded. If mlStaticCheckAssets is true and this is false, then no errors will be thrown for library modules. Defaults to false. |
| mlTdeValidationEnabled | New in 3.13.0 - when true, then when a TDE template is loaded into a schemas database, it will first be validated. If that validation fails, the error from MarkLogic will be thrown and displayed. Defaults to true. |
| mlUseRoxyTokenPrefix | When mlReplaceTokensInModules is set to true, then if this is true as well, tokens in modules are expected to start with "@ml.". If you do not want this behavior, set this property to false. In version 3.2.0 and later, defaults to false; prior to 3.2.0, defaults to true. |

# Entity Services properties 

These properties specify how Entity Services models should be processed. 

| Property  | Description |
| --- | --- |
| mlGenerateDatabaseProperties | Whether or not to generate database properties. Defaults to true. |
| mlGenerateExtractionTemplate | Whether or not to generate an extraction template. Defaults to true. |
| mlGenerateInstanceConverter | Whether or not to generate instance converters. Defaults to true. |
| mlGenerateSchema | Whether or not to generate a schema. Defaults to true. |
| mlGenerateSearchOptions | Whether or not to generate search options. Defaults to true. |
| mlInstanceConverterPath | Directory path for instance converters, relative to mlModulePaths. Defaults to ext/entity-services. |
| mlModelsDatabase | New in 3.4.1 - defines the database that Entity Services models are loaded into. If not specified, defaults to the content database. |
| mlModelsPath | Directory path for Entity Services models. Defaults to data/entity-services. |

# Plugin properties

Added in 3.13.0 - see [[Installing plugins]] for more information, and the [ml-app-deployer docs](https://github.com/marklogic-community/ml-app-deployer/wiki/Plugins) for a list of the properties for configuring this feature. 
