As of version 2.5.0, you can load modules - via any task, such as mlDeploy, mlLoadModules, and (most typically) [[mlWatch|Watching-for-module-changes]] - with static checking of asset modules enabled. The REST API will automatically statically check a REST API service, transform, or options file, but it won't do so for asset modules - i.e. those loaded via `/v1/documents` or `/v1/ext` and stored in your project under `/ext` or `/root`. 

To enable this, just include the following command line property flag:

    gradle mlWatch -PmlStaticCheckAssets=true

Then, when mlWatch tries to load an asset module that has a compilation error in it, the error (with line number) will be written both to stdout where mlWatch is running and to the MarkLogic ErrorLog.txt file (it's currently logged via xdmp:log; please file an issue if you'd prefer that xdmp:trace be used). This helps you know immediately when you have an issue, as opposed to finding out later when e.g. manually testing or running an automated test. 

**A note about library modules**

This feature will attempt to static check both main and library modules. For library modules, it does some hacky parsing of the module contents to determine its namespace so that it can use `xdmp:invoke` on a script that imports the module. It assumes your library modules have at least this on one line (you can use either single or double quotes around the namespace):

    module namespace someprefix = "any:namespace";

As long as that's the case, the feature should be able to extract the module's namespace and include it in an XQuery script that is then invoked via `xdmp:invoke`. If you run into problems with this, please file an issue and include your module's namespace declaration.

Also, this doesn't work for server-side JavaScript modules yet, only XQuery. If you'd like SSJS support, please file an issue for that too.