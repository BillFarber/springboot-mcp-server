While developing code in MarkLogic, you ideally want a cycle of:

1. Create or modify a module
2. Test it, either manually or via an automated test

That is - ideally, you don't need to take any action to load the new/modified module into your modules database. 

To support this cycle, ml-gradle features a task named mlWatch that will load new/modified modules as you create/modify them. It checks every second for any such modules, so you have at most a one second delay. 

mlWatch will also tell you what it's loading when you use the Gradle "-i" or "--info" flag, so it's best to run it as:

    gradle -i mlWatch

## Doing something after one or more files are loaded

In version 3.8.3 of ml-gradle, you can add an implementation of [java.util.function.Consumer](https://docs.oracle.com/javase/8/docs/api/java/util/function/Consumer.html) that accepts a java.util.Set of [Spring Resource](https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/core/io/Resource.html) objects. If mlWatch loads at least one file, the Consumer will be invoked with a Set with one Resource per file that was loaded. The original use case for this was to make a call to MarkLogic to clear a cache, but your consumer of course can perform any action. 

Here's an example of simply printing out the set of loaded modules:

    mlWatch.onModulesLoaded = {
      set -> println "Modules loaded: " + set
    }

## Ignoring already "dirty" files

In version 3.1.0 of ml-gradle, you can also tell mlWatch to ignore any files that are "dirty" - i.e. ones that have been created/modified since modules were last loaded. mlWatch will then only load modules that are created/modified after mlWatch starts watching:

    gradle -i mlWatch -PignoreDirty=true

Also see [Loading modules with static checking](https://github.com/marklogic-community/ml-gradle/wiki/Loading-modules-with-static-checking) for support for statically checking modules as they're loaded. 