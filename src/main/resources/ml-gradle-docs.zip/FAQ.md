**Where should I start to learn ml-gradle?**

Start with the [[Getting Started guide|Getting-started]]. 

**But how does ml-gradle really work?**

See [[How ml-gradle works|How-ml-gradle-works]].

**I'm using Roxy; how would I start using ml-gradle?**

See [[Migrating a Roxy project to ml gradle|Migrating a Roxy project to ml gradle]]

**I'm using Ant or Maven; should I start using Gradle and ml-gradle?**

If you're currently using Ant or Maven and are wondering about Gradle, there are many comparisons of these tools on the Internet; certainly consider making thes shift. If you are using Ant, it's easy to invoke Ant tasks from Gradle. And if you can't move away from Maven, you can still [invoke Gradle tasks from Maven](https://github.com/if6was9/gradle-maven-plugin).

**What are all the different ways to configure ml-gradle?**

See [[Configuring ml-gradle|Configuring-ml-gradle]].

**What are all the properties that ml-gradle looks for?**

See [[the Property Reference|Property-reference]].

**How do I override properties for local development or some other environment?**

See [this project](../tree/master/examples/properties-project) for an example of using the Gradle properties plugin for customizing properties for local development and any other environment. 

**How are the tokens set in configuration files?**

See [[Configuring resources]].

**How do I add a new resource or transform?**

See [[Creating a new resource|Common-tasks#create-a-new-resource]] and [[Creating a new transform|Common-tasks#create-a-new-transform]].

**How do I perform a deployment in an environment that doesn't have access to my dependency repositories?**

The [disconnected-project build file](https://github.com/marklogic-community/ml-gradle/tree/master/examples/disconnected-project) shows a non-ml-gradle-specific way of creating a package that can be used for offline/disconnected deployments that don't depend on any repositories. 

**Do the names of resource files matter?**

For most resources, the names of resource files are used to determine the order in which they're sent to MarkLogic. As of 3.4.0, the exceptions to this are roles and database files. ml-gradle will first load roles without references to other roles (to avoid any errors), and then update every role with its dependent roles. For databases, ml-gradle will sort them based on their dependencies between each other. 

**How do I extend ml-gradle?**

The easiest way to extend what ml-gradle can do is by [[writing your own commands|Writing-your-own-command]] and [[writing your own tasks|Writing-your-own-management-task]].