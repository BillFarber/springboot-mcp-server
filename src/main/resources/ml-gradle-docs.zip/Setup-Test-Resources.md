If the _mlTestRestPort_ property is specified in your gradle.properties file and given a port number value, then the next time you deploy your MarkLogic application, the following additional resources are created.

* A test database with a defeault name of _mlAppName_-test-content
  * The database properties are a replica of _mlAppName_-content
* A test REST server named _mlAppName_-test
  * The application server properties are a replica of _mlAppName_
  * The database points to _mlAppName_-test-content
  * The modules database points to _mlAppName_-modules

As of version 3.3.1, the names of the REST server and test REST server can be modified by manipulating the mlAppConfig object in build.gradle:

    ext {
      mlAppConfig.restServerName = "my-custom-name"
      mlAppConfig.testRestServerName = "my-custom-test-name"
    }

An external test framework would delete all or a subset of content from the test database after each test execution.  Asserts would be made on the state of the test content database after each run.  

Gradle can also be used to [execute Java unit tests](https://docs.gradle.org/current/userguide/java_plugin.html#sec:java_test) through the Java plugin. 

