Version 3.13.0 added a simple mechanism for loading data as part of a deployment. This includes loading data that is part of an mlBundle dependency. 

For more information, including properties, see [Loading data in the ml-app-deployer project](https://github.com/marklogic-community/ml-app-deployer/wiki/Loading-data) and the [example project](https://github.com/marklogic-community/ml-gradle/tree/dev/examples/dependency-project) that shows data being loaded from a dependency. 

Also see [[Configuring security]] for information on the MarkLogic user used for this action, along with the required roles and privileges. 